<template>
  <div class="min-h-screen flex flex-col bg-gradient-to-br from-gray-50 to-blue-50">
    <!-- Header -->
    <header class="bg-white shadow-sm">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div class="flex justify-between items-center">
          <div class="flex items-center">
            <h1 class="ml-4 text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-cyan-500">
              IR Retrieval System
            </h1>
          </div>
          <nav class="hidden md:flex space-x-8">
            <a href="#features" class="text-gray-700 hover:text-blue-600 font-medium">Features</a>
            <a href="#how-it-works" class="text-gray-700 hover:text-blue-600 font-medium">How It Works</a>
            <a href="#datasets" class="text-gray-700 hover:text-blue-600 font-medium">Datasets</a>
            <a href="#about" class="text-gray-700 hover:text-blue-600 font-medium">About</a>
          </nav>
          <button class="md:hidden text-gray-500 hover:text-gray-900">
            <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
            </svg>
          </button>
        </div>
      </div>
    </header>

    <!-- Hero Section -->
    <section class="relative bg-white overflow-hidden">
      <div class="max-w-7xl mx-auto">
        <div class="relative z-10 pb-8 bg-white sm:pb-16 md:pb-20 lg:max-w-2xl lg:w-full lg:pb-28 xl:pb-32">
          <div class="pt-10 sm:pt-16 lg:pt-8 lg:pb-14 lg:overflow-hidden">
            <div class="mt-10 mx-auto max-w-7xl px-4 sm:mt-12 sm:px-6 md:mt-16 lg:mt-20 lg:px-8 xl:mt-28">
              <div class="sm:text-center lg:text-left">
                <h2 class="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl">
                  <span class="block">Advanced</span>
                  <span class="block text-blue-600">Information Retrieval</span>
                </h2>
                <p class="mt-3 text-base text-gray-500 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-0">
                  Search through 500K+ documents using multiple retrieval methods including TF-IDF, BM25, BERT embeddings and hybrid approaches.
                </p>
                <div class="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start">
                  <div class="rounded-md shadow">
                    <a href="#search" class="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 md:py-4 md:text-lg md:px-10">
                      Start Searching
                    </a>
                  </div>
                  <div class="mt-3 sm:mt-0 sm:ml-3">
                    <a href="#how-it-works" class="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 md:py-4 md:text-lg md:px-10">
                      How it works
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2">
          <img class="h-56 w-full object-cover sm:h-72 md:h-96 lg:w-full lg:h-full" src="/images/search-hero.jpg" alt="Search interface">
        </div>
      </div>
    </section>

    <!-- Main Search Section -->
    <section id="search" class="py-12 bg-gray-50">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Dataset Selection -->
        <div class="max-w-3xl mx-auto mb-8">
          <h2 class="text-center text-3xl font-extrabold text-gray-900 mb-6">
            Select Your Dataset
          </h2>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div 
              v-for="dataset in datasets"
              :key="dataset.id"
              @click="selectDataset(dataset.id)"
              class="cursor-pointer bg-white overflow-hidden shadow rounded-lg border-2 transition-all duration-300"
              :class="{
                'border-blue-500 transform scale-105': selectedDataset === dataset.id,
                'border-transparent hover:border-gray-300': selectedDataset !== dataset.id
              }"
            >
              <div class="px-4 py-5 sm:p-6 flex items-start">
                <div class="flex-shrink-0 bg-blue-500 rounded-md p-3">
                  <img :src="dataset.icon" :alt="dataset.name" class="h-12 w-12">
                </div>
                <div class="ml-5">
                  <h3 class="text-lg leading-6 font-medium text-gray-900">{{ dataset.name }}</h3>
                  <p class="mt-1 text-sm text-gray-500">
                    {{ dataset.docs }} documents • {{ dataset.size }}
                  </p>
                  <p class="mt-2 text-sm text-gray-600">
                    {{ dataset.description }}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Search Interface -->
        <div class="max-w-4xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
          <div class="p-6">
            <!-- Search Box -->
            <div class="mb-6">
              <label for="search" class="sr-only">Search</label>
              <div class="relative rounded-md shadow-sm">
                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <svg class="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>
                <input
                  id="search"
                  v-model="searchQuery"
                  @keyup.enter="performSearch"
                  type="text"
                  class="block w-full pl-10 pr-12 py-4 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-lg"
                  placeholder="Enter your search query..."
                >
                <div class="absolute inset-y-0 right-0 flex items-center pr-3">
                  <button
                    @click="performSearch"
                    :disabled="!searchQuery || !selectedDataset"
                    class="p-1 rounded-full text-gray-400 hover:text-blue-500 focus:outline-none"
                    :class="{ 'cursor-not-allowed': !searchQuery || !selectedDataset }"
                  >
                    <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>

            <!-- Search Methods -->
            <div class="mb-6">
              <h3 class="text-sm font-medium text-gray-500 uppercase tracking-wider mb-3">
                Retrieval Methods
              </h3>
              <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <button
                  v-for="method in searchMethods"
                  :key="method.value"
                  @click="selectedMethod = method.value"
                  class="p-4 rounded-lg border transition-all"
                  :class="[
                    selectedMethod === method.value
                      ? 'border-blue-500 bg-blue-50 shadow-inner'
                      : 'border-gray-200 hover:border-blue-300',
                    !selectedDataset ? 'opacity-50 cursor-not-allowed' : ''
                  ]"
                  :disabled="!selectedDataset"
                >
                  <div class="flex items-center">
                    <span class="flex-shrink-0 w-10 h-10 flex items-center justify-center rounded-full mr-3"
                      :class="{
                        'bg-blue-100 text-blue-600': method.type === 'Basic',
                        'bg-purple-100 text-purple-600': method.type === 'Advanced'
                      }"
                    >
                      <svg v-if="method.value === 'bm25' || method.value === 'tfidf'" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
                      </svg>
                      <svg v-if="method.value === 'word2vec'" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
                      </svg>
                      <svg v-if="method.value === 'bert'" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                      <svg v-if="method.value === 'hybrid'" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                      </svg>
                    </span>
                    <div class="text-left">
                      <p class="font-medium text-gray-900">{{ method.name }}</p>
                      <p class="text-xs" 
                        :class="{
                          'text-blue-600': method.type === 'Basic',
                          'text-purple-600': method.type === 'Advanced'
                        }"
                      >
                        {{ method.type }}
                      </p>
                    </div>
                  </div>
                </button>
              </div>
            </div>

            <!-- Search Options -->
            <div class="flex flex-wrap justify-between items-center gap-4">
              <div class="flex items-center space-x-4">
                <div class="flex items-center">
                  <input
                    id="query-expansion"
                    v-model="queryExpansion"
                    type="checkbox"
                    class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  >
                  <label for="query-expansion" class="ml-2 block text-sm text-gray-700">
                    Query Expansion
                  </label>
                </div>
                <div class="flex items-center">
                  <input
                    id="spell-check"
                    v-model="spellCheck"
                    type="checkbox"
                    class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  >
                  <label for="spell-check" class="ml-2 block text-sm text-gray-700">
                    Spell Check
                  </label>
                </div>
              </div>
              
              <button
                @click="performSearch"
                :disabled="!searchQuery || !selectedDataset"
                class="px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-500 text-white rounded-lg shadow-md hover:shadow-lg transition-all flex items-center"
                :class="{ 'opacity-50 cursor-not-allowed': !searchQuery || !selectedDataset }"
              >
                <svg class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                Execute Search
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Results Section -->
    <section v-if="results.length > 0" class="py-12 bg-gray-50">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
          <!-- Results Header -->
          <div class="px-6 py-5 border-b border-gray-200 flex flex-wrap justify-between items-center gap-4">
            <div>
              <h2 class="text-lg font-medium text-gray-900">
                Search Results for "{{ searchQuery }}"
              </h2>
              <p class="text-sm text-gray-500 mt-1">
                {{ results.length }} documents found in {{ selectedDatasetName }} dataset
              </p>
            </div>
            <div class="flex items-center space-x-4">
              <div class="relative">
                <select 
                  v-model="resultsPerPage"
                  class="appearance-none bg-white border border-gray-300 rounded-md pl-3 pr-8 py-2 text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="10">10 per page</option>
                  <option value="25">25 per page</option>
                  <option value="50">50 per page</option>
                </select>
                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                  <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </div>
              <button 
                @click="exportResults"
                class="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                <svg class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
                Export
              </button>
            </div>
          </div>
          
          <!-- Results List -->
          <div class="divide-y divide-gray-200">
            <div v-for="(result, index) in paginatedResults" :key="result.id" class="p-6 hover:bg-gray-50 transition-colors">
              <div class="flex items-start">
                <!-- Rank Indicator -->
                <div 
                  class="flex-shrink-0 flex items-center justify-center w-10 h-10 rounded-full mr-4 mt-1"
                  :class="[
                    index + 1 + ((currentPage - 1) * resultsPerPage) <= 3 
                      ? 'bg-gradient-to-br from-blue-500 to-cyan-400 text-white'
                      : 'bg-gray-100 text-gray-600'
                  ]"
                >
                  <span class="font-medium">{{ index + 1 + ((currentPage - 1) * resultsPerPage) }}</span>
                </div>
                
                <!-- Content -->
                <div class="flex-1 min-w-0">
                  <h3 class="text-lg font-medium text-gray-900 mb-1">
                    <a href="#" class="hover:text-blue-600 hover:underline">
                      {{ result.title }}
                    </a>
                  </h3>
                  <p class="text-gray-600 text-sm mb-2 line-clamp-2">
                    {{ result.snippet }}
                  </p>
                  
                  <!-- Metadata -->
                  <div class="flex flex-wrap gap-2 mt-3">
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      Score: {{ result.score }}
                    </span>
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                      {{ result.date }}
                    </span>
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                      {{ result.method }}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <!-- Pagination -->
          <div class="px-6 py-4 border-t border-gray-200 flex items-center justify-between">
            <div class="flex-1 flex justify-between sm:hidden">
              <button 
                @click="prevPage"
                :disabled="currentPage === 1"
                class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
              >
                Previous
              </button>
              <button 
                @click="nextPage"
                :disabled="currentPage === totalPages"
                class="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
              >
                Next
              </button>
            </div>
            <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
              <div>
                <p class="text-sm text-gray-700">
                  Showing <span class="font-medium">{{ ((currentPage - 1) * resultsPerPage) + 1 }}</span> to 
                  <span class="font-medium">{{ Math.min(currentPage * resultsPerPage, results.length) }}</span> of 
                  <span class="font-medium">{{ results.length }}</span> results
                </p>
              </div>
              <div>
                <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                  <button
                    @click="prevPage"
                    :disabled="currentPage === 1"
                    class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                    :class="{ 'cursor-not-allowed opacity-50': currentPage === 1 }"
                  >
                    <span class="sr-only">Previous</span>
                    <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
                    </svg>
                  </button>
                  <button
                    v-for="page in visiblePages"
                    :key="page"
                    @click="goToPage(page)"
                    :class="[
                      'relative inline-flex items-center px-4 py-2 border text-sm font-medium',
                      page === currentPage 
                        ? 'z-10 bg-blue-50 border-blue-500 text-blue-600'
                        : 'bg-white border-gray-300 text-gray-500 hover:bg-gray-50'
                    ]"
                  >
                    {{ page }}
                  </button>
                  <button
                    @click="nextPage"
                    :disabled="currentPage === totalPages"
                    class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                    :class="{ 'cursor-not-allowed opacity-50': currentPage === totalPages }"
                  >
                    <span class="sr-only">Next</span>
                    <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                  </button>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- How It Works Section -->
    <section id="how-it-works" class="py-16 bg-white">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="lg:text-center">
          <h2 class="text-base text-blue-600 font-semibold tracking-wide uppercase">Process</h2>
          <p class="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            How Our IR System Works
          </p>
          <p class="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
            Advanced information retrieval pipeline with multiple representation methods
          </p>
        </div>

        <div class="mt-16">
          <div class="space-y-16 lg:space-y-0 lg:grid lg:grid-cols-3 lg:gap-x-8 lg:gap-y-16">
            <div v-for="feature in features" :key="feature.name" class="text-center">
              <div class="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white mx-auto">
                <svg v-if="feature.name === 'Data Preprocessing'" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                <svg v-if="feature.name === 'Multiple Representations'" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
                </svg>
                <svg v-if="feature.name === 'Efficient Indexing'" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4" />
                </svg>
                <svg v-if="feature.name === 'Query Processing'" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                </svg>
                <svg v-if="feature.name === 'Ranking Algorithms'" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                </svg>
                <svg v-if="feature.name === 'Multilingual Support'" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129" />
                </svg>
              </div>
              <h3 class="mt-6 text-lg font-medium text-gray-900">{{ feature.name }}</h3>
              <p class="mt-2 text-base text-gray-500">
                {{ feature.description }}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Datasets Section -->
    <section id="datasets" class="py-16 bg-gray-50">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center">
          <h2 class="text-base text-blue-600 font-semibold tracking-wide uppercase">Datasets</h2>
          <p class="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            Available Collections
          </p>
          <p class="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
            High-quality datasets with over 200K documents each
          </p>
        </div>

        <div class="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-2">
          <div v-for="dataset in datasets" :key="dataset.id" class="bg-white overflow-hidden shadow rounded-lg">
            <div class="px-4 py-5 sm:p-6">
              <div class="flex items-center">
                <div class="flex-shrink-0 bg-blue-500 rounded-md p-3">
                  <img :src="dataset.icon" :alt="dataset.name" class="h-12 w-12">
                </div>
                <div class="ml-5 w-0 flex-1">
                  <h3 class="text-lg font-medium text-gray-900">{{ dataset.name }}</h3>
                  <p class="mt-1 text-sm text-gray-500">
                    {{ dataset.docs }} documents • {{ dataset.size }}
                  </p>
                </div>
              </div>
              <div class="mt-4">
                <p class="text-sm text-gray-600">
                  {{ dataset.fullDescription }}
                </p>
              </div>
              <div class="mt-5">
                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                  Includes qrels
                </span>
                <span class="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                  Testing data available
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-800">
      <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div class="xl:grid xl:grid-cols-3 xl:gap-8">
          <div class="space-y-8 xl:col-span-1">
            <img class="h-10" src="/images/logo-white.png" alt="IR System">
            <p class="text-gray-300 text-base">
              Advanced Information Retrieval System supporting multiple retrieval methods and large document collections.
            </p>
            <div class="flex space-x-6">
              <a href="#" class="text-gray-400 hover:text-white">
                <span class="sr-only">GitHub</span>
                <svg class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                  <path fill-rule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" clip-rule="evenodd" />
                </svg>
              </a>
              <a href="#" class="text-gray-400 hover:text-white">
                <span class="sr-only">Twitter</span>
                <svg class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                </svg>
              </a>
            </div>
          </div>
          <div class="mt-12 grid grid-cols-2 gap-8 xl:mt-0 xl:col-span-2">
            <div class="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <h3 class="text-sm font-semibold text-gray-300 tracking-wider uppercase">
                  Resources
                </h3>
                <ul class="mt-4 space-y-4">
                  <li>
                    <a href="https://ir-datasets.com" class="text-base text-gray-400 hover:text-white">
                      IR Datasets
                    </a>
                  </li>
                  <li>
                    <a href="#" class="text-base text-gray-400 hover:text-white">
                      Documentation
                    </a>
                  </li>
                </ul>
              </div>
              <div class="mt-12 md:mt-0">
                <h3 class="text-sm font-semibold text-gray-300 tracking-wider uppercase">
                  Support
                </h3>
                <ul class="mt-4 space-y-4">
                  <li>
                    <a href="#" class="text-base text-gray-400 hover:text-white">
                      Contact
                    </a>
                  </li>
                  <li>
                    <a href="#" class="text-base text-gray-400 hover:text-white">
                      FAQ
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <h3 class="text-sm font-semibold text-gray-300 tracking-wider uppercase">
                  Legal
                </h3>
                <ul class="mt-4 space-y-4">
                  <li>
                    <a href="#" class="text-base text-gray-400 hover:text-white">
                      Privacy
                    </a>
                  </li>
                  <li>
                    <a href="#" class="text-base text-gray-400 hover:text-white">
                      Terms
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="mt-12 border-t border-gray-700 pt-8">
          <p class="text-base text-gray-400 text-center">
            &copy; 2023 IR Retrieval Pro. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  </div>
</template>


<style>
/* Custom animations */
.animate-float {
  animation: float 6s ease-in-out infinite;
}
@keyframes float {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-10px); }
}

/* Smooth transitions */
.fade-enter-active, .fade-leave-active {
  transition: opacity 0.3s;
}
.fade-enter-from, .fade-leave-to {
  opacity: 0;
}

/* Responsive tweaks */
@media (max-width: 640px) {
  .search-methods-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}
</style>
<script setup>
import { ref, computed } from 'vue'

// State
const searchQuery = ref('')
const selectedDataset = ref(null)
const selectedMethod = ref('bm25')
const queryExpansion = ref(false)
const spellCheck = ref(false)
const results = ref([])
const currentPage = ref(1)
const resultsPerPage = ref(10)
const isLoading = ref(false)
const showDatasetModal = ref(false)

// بيانات تجريبية
const sampleData = {
  covid19: [
    {
      id: 1,
      title: "Clinical characteristics of coronavirus disease 2019 in China",
      snippet: "During the first 2 months of the current outbreak, Covid-19 spread rapidly throughout China and caused varying degrees of illness. Patients often presented without fever, and many did not have abnormal radiologic findings.",
      score: 0.95,
      date: "2020-02-28",
      authors: "Guan W, Ni Z, Hu Y, et al.",
      method: "BM25"
    },
    {
      id: 2,
      title: "A novel coronavirus outbreak of global health concern",
      snippet: "The outbreak of the 2019 novel coronavirus (2019-nCoV) represents a pandemic threat that has been declared a public health emergency of international concern.",
      score: 0.89,
      date: "2020-01-24",
      authors: "Wang C, Horby PW, Hayden FG, Gao GF",
      method: "TF-IDF"
    },
    {
      id: 3,
      title: "Epidemiological and clinical characteristics of 99 cases of 2019 novel coronavirus pneumonia in Wuhan, China",
      snippet: "The 2019 novel coronavirus pneumonia (NCP) has caused an outbreak in Wuhan, China. This study aimed to investigate the epidemiological and clinical characteristics of NCP.",
      score: 0.87,
      date: "2020-01-30",
      authors: "Chen N, Zhou M, Dong X, et al.",
      method: "BERT"
    },
    {
      id: 4,
      title: "Remdesivir in adults with severe COVID-19: a randomised, double-blind, placebo-controlled, multicentre trial",
      snippet: "Although remdesivir was not associated with statistically significant clinical benefits, the numerical reduction in time to clinical improvement in those treated earlier requires confirmation in larger studies.",
      score: 0.82,
      date: "2020-04-29",
      authors: "Wang Y, Zhang D, Du G, et al.",
      method: "Hybrid"
    }
  ],
  trecArabic: [
    {
      id: 1,
      title: "تأثير التغيرات المناخية على الزراعة في الوطن العربي",
      snippet: "تشير الدراسات الحديثة إلى أن التغيرات المناخية ستؤثر بشكل كبير على القطاع الزراعي في المنطقة العربية خلال العقدين المقبلين.",
      score: 0.92,
      date: "2019-05-15",
      authors: "محمد أحمد، علي حسن",
      method: "BM25"
    },
    {
      id: 2,
      title: "تطور التعليم العالي في الدول العربية خلال العشر سنوات الماضية",
      snippet: "شهدت الجامعات العربية تطوراً ملحوظاً في البنية التحتية والبرامج الأكاديمية، لكنها ما زالت متأخرة في مجال البحث العلمي.",
      score: 0.85,
      date: "2020-03-10",
      authors: "سميرة خالد، فارس ناصر",
      method: "TF-IDF"
    },
    {
      id: 3,
      title: "دور الذكاء الاصطناعي في تحسين الرعاية الصحية بالعالم العربي",
      snippet: "بدأت بعض الدول العربية في تطبيق حلول الذكاء الاصطناعي في القطاع الصحي، مما ساهم في تحسين جودة الخدمات وتقليل التكاليف.",
      score: 0.78,
      date: "2021-01-20",
      authors: "نادية عمر، خالد سعيد",
      method: "BERT"
    }
  ]
}

// Datasets
const datasets = [
  {
    id: "covid19",
    name: "COVID-19 Research Papers",
    icon: "/images/covid-icon.png",
    docs: "250K+",
    size: "1.2GB",
    description: "Scientific papers about COVID-19",
    fullDescription: "This dataset contains over 250,000 scholarly articles about COVID-19, SARS-CoV-2, and related coronaviruses."
  },
  {
    id: "trec-arabic",
    name: "TREC Arabic Corpus",
    icon: "/images/arabic-icon.png",
    docs: "300K+",
    size: "2.4GB",
    description: "Arabic news articles",
    fullDescription: "The TREC Arabic Corpus contains Arabic news articles from various sources used in TREC evaluations."
  }
]

// Search methods
const searchMethods = [
  { 
    value: "bm25", 
    name: "BM25", 
    type: "Basic",
    description: "Probabilistic retrieval function" 
  },
  { 
    value: "tfidf", 
    name: "TF-IDF", 
    type: "Basic",
    description: "Term frequency-inverse document frequency" 
  },
  { 
    value: "word2vec", 
    name: "Word2Vec", 
    type: "Advanced",
    description: "Dense vector embeddings" 
  },
  { 
    value: "bert", 
    name: "BERT", 
    type: "Advanced",
    description: "Contextual embeddings" 
  },
  { 
    value: "hybrid", 
    name: "Hybrid", 
    type: "Advanced",
    description: "Combination of multiple methods" 
  }
]

// Features
const features = [
  {
    name: "Data Preprocessing",
    description: "Tokenization, stemming, lemmatization, stopword removal and normalization for clean data."
  },
  {
    name: "Multiple Representations",
    description: "Supports VSM (TF-IDF), BM25, Word2Vec, BERT embeddings and hybrid approaches."
  },
  {
    name: "Efficient Indexing",
    description: "Inverted index and other indexing methods for fast retrieval."
  },
  {
    name: "Query Processing",
    description: "Advanced query parsing, expansion and refinement techniques."
  },
  {
    name: "Ranking Algorithms",
    description: "Multiple ranking functions including cosine similarity and custom scoring."
  },
  {
    name: "Multilingual Support",
    description: "Designed to work with multiple languages including Arabic and English."
  }
]

// Computed properties
const selectedDatasetName = computed(() => {
  return datasets.find(d => d.id === selectedDataset.value)?.name || ''
})

const paginatedResults = computed(() => {
  const start = (currentPage.value - 1) * resultsPerPage.value
  const end = start + resultsPerPage.value
  return results.value.slice(start, end)
})

const totalPages = computed(() => {
  return Math.ceil(results.value.length / resultsPerPage.value)
})

const visiblePages = computed(() => {
  const pages = []
  const maxVisible = 5
  let start = Math.max(1, currentPage.value - Math.floor(maxVisible / 2))
  let end = Math.min(totalPages.value, start + maxVisible - 1)
  
  if (end - start + 1 < maxVisible) {
    start = Math.max(1, end - maxVisible + 1)
  }
  
  for (let i = start; i <= end; i++) {
    pages.push(i)
  }
  
  return pages
})

// Methods
const selectDataset = (datasetId) => {
  selectedDataset.value = datasetId
  results.value = []
  showDatasetModal.value = false
}

const performSearch = () => {
  if (!selectedDataset.value || !searchQuery.value.trim()) {
    alert("Please select a dataset and enter a search query")
    return
  }
  
  isLoading.value = true
  results.value = []
  
  // Simulate API call with timeout
  setTimeout(() => {
    try {
      const query = searchQuery.value.toLowerCase()
      let datasetResults = []
      
      if (selectedDataset.value === 'covid19') {
        datasetResults = [...sampleData.covid19]
      } else if (selectedDataset.value === 'trec-arabic') {
        datasetResults = [...sampleData.trecArabic]
      }
      
      // Filter results based on query
      results.value = datasetResults.filter(item => {
        return item.title.toLowerCase().includes(query) || 
               item.snippet.toLowerCase().includes(query)
      })
      
      // Apply method-specific scoring
      results.value = results.value.map(item => {
        let score = item.score
        
        // Adjust score based on selected method
        if (selectedMethod.value === 'bm25') {
          score = item.score * 0.95 + Math.random() * 0.05
        } else if (selectedMethod.value === 'tfidf') {
          score = item.score * 0.9 + Math.random() * 0.1
        } else if (selectedMethod.value === 'bert') {
          score = item.score * 0.85 + Math.random() * 0.15
        } else if (selectedMethod.value === 'hybrid') {
          score = item.score * 0.92 + Math.random() * 0.08
        }
        
        return {
          ...item,
          score: score.toFixed(3),
          method: selectedMethod.value.toUpperCase()
        }
      })
      
      // Sort by score
      results.value.sort((a, b) => b.score - a.score)
      
      // Add no results message if empty
      if (results.value.length === 0) {
        results.value.push({
          id: 0,
          title: "No results found",
          snippet: `Your search for "${searchQuery.value}" did not match any documents.`,
          score: 0,
          date: "",
          authors: "",
          method: selectedMethod.value.toUpperCase()
        })
      }
      
    } catch (error) {
      console.error("Search error:", error)
      results.value = [{
        id: 0,
        title: "Search error",
        snippet: "An error occurred while performing your search. Please try again.",
        score: 0,
        date: "",
        authors: "",
        method: ""
      }]
    } finally {
      isLoading.value = false
      currentPage.value = 1
    }
  }, 800) // Simulate network delay
}

const prevPage = () => {
  if (currentPage.value > 1) {
    currentPage.value--
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }
}

const nextPage = () => {
  if (currentPage.value < totalPages.value) {
    currentPage.value++
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }
}

const goToPage = (page) => {
  currentPage.value = page
  window.scrollTo({ top: 0, behavior: 'smooth' })
}

const exportResults = () => {
  if (results.value.length === 0) {
    alert("No results to export")
    return
  }
  
  const csvContent = [
    ['Rank', 'Title', 'Score', 'Date', 'Method'].join(','),
    ...results.value.map((item, index) => [
      index + 1,
      `"${item.title.replace(/"/g, '""')}"`,
      item.score,
      item.date,
      item.method
    ].join(','))
  ].join('\n')
  
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.setAttribute('download', `search_results_${selectedDataset.value}.csv`)
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}
</script>
