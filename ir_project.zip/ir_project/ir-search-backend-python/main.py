# main.py

import argparse

from core.tfidf import TFIDFSearcher
from core.bert_embedder import BERTRetriever
from core.bm25 import BM25Retriever
from core.hybrid import HybridRetriever

def print_results(results):
    print("\nTop Results:")
    for doc_id, score in results:
        print(f"Doc ID: {doc_id} | Score: {score:.4f}")

def main():
    parser = argparse.ArgumentParser(description="IR System CLI")
    parser.add_argument("--query", type=str, required=True, help="Query string to search for")
    parser.add_argument("--method", type=str, choices=["tfidf", "bert", "bm25", "hybrid"], required=True, help="Retrieval method")
    parser.add_argument("--top_k", type=int, default=5, help="Number of top results to return")
    args = parser.parse_args()

    if args.method == "tfidf":
        searcher = TFIDFSearcher()
        results = searcher.search(args.query, top_k=args.top_k)

    elif args.method == "bert":
        searcher = BERTRetriever()
        results = searcher.search(args.query, top_k=args.top_k)

    elif args.method == "bm25":
        searcher = BM25Retriever()
        results = searcher.search(args.query, top_k=args.top_k)

    elif args.method == "hybrid":
        searcher = HybridRetriever()
        results = searcher.hybrid_search(args.query, top_k=args.top_k)

    print_results(results)

if __name__ == "__main__":
    main()
