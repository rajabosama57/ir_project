# ranking/custom_preprocessor.py

import re

def custom_preprocessor(text):
    """
    دالة بسيطة لمعالجة النصوص:
    - تحويل لحروف صغيرة
    - إزالة الرموز الخاصة
    - إزالة زوائد المسافات
    """
    text = text.lower()
    text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def custom_tokenizer(text):
    # تقسيم النص إلى كلمات بسيطة جدًا
    return text.split()