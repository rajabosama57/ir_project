import numpy as np
from sklearn.metrics.pairwise import cosine_similarity


def rank_documents(query_vector, doc_vectors, doc_ids, method="cosine"):
    """
    مطابقة الاستعلام وترتيب النتائج.

    Args:
        query_vector (np.ndarray): تمثيل الاستعلام (1, dim) أو (dim,)
        doc_vectors (np.ndarray): تمثيل الوثائق (n_docs, dim)
        doc_ids (list): قائمة معرفات الوثائق
        method (str): طريقة التشابه: "cosine" أو "dot"

    Returns:
        List of tuples: [(doc_id, score), ...] مرتبة تنازليًا حسب score
    """

    # تأكد أن الشكل صحيح
    if len(query_vector.shape) == 1:
        query_vector = query_vector.reshape(1, -1)

    if method == "cosine":
        similarities = cosine_similarity(query_vector, doc_vectors)[0]
    elif method == "dot":
        similarities = np.dot(doc_vectors, query_vector.T).flatten()
    else:
        raise ValueError(f"Unknown method: {method}")

    # ترتيب النتائج حسب أعلى درجة تشابه
    ranked_indices = np.argsort(similarities)[::-1]  # تنازليًا
    ranked_results = [(doc_ids[i], float(similarities[i])) for i in ranked_indices]

    return ranked_results


# مثال استخدام:
if __name__ == "__main__":
    # نفترض أن لدينا استعلام ووثائق تم تحويلها بالفعل
    query_vec = np.array([0.1, 0.3, 0.5])
    doc_vecs = np.array([
        [0.1, 0.3, 0.4],
        [0.2, 0.1, 0.0],
        [0.0, 0.4, 0.5]
    ])
    doc_ids = ["doc1", "doc2", "doc3"]

    results = rank_documents(query_vec, doc_vecs, doc_ids, method="cosine")

    print("[INFO] 🔍 Results:")
    for doc_id, score in results:
        print(f"{doc_id}: {score:.4f}")
