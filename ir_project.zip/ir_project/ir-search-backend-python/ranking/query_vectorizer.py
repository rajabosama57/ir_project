# ranking/query_vectorizer.py
from joblib import load
import ranking.custom_preprocessor   # <=== أضف هذا السطر
import numpy as np
from core.preprocessor import TextPreprocessor


preproc = TextPreprocessor()

def vectorize_query_word2vec(query_text, model_path="models/word2vec_model.joblib"):
    import ranking.custom_preprocessor
    model = load(model_path)
    tokens = preproc.tokenize(query_text)
    tokens = preproc.remove_stop_words(tokens)
    tokens = preproc.stem_tokens(tokens)

    vectors = [model.wv[word] for word in tokens if word in model.wv]
    if vectors:
        return np.mean(vectors, axis=0)
    else:
        return np.zeros(model.vector_size)

def vectorize_query_tfidf(query_text, vectorizer_path="models/tfidf_vectorizer.joblib"):
    vectorizer = load(vectorizer_path)
    cleaned_text = preproc.normalize_text(query_text)
    return vectorizer.transform([cleaned_text]).toarray()[0]
