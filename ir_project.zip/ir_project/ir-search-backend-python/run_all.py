import importlib

# قائمة السكربتات بالنماذج مع أسمائها
search_scripts = [
    ("BERT", "search.bert_search"),
    ("BM25 Query", "search.bm25_query"),
    ("BM25 Search", "search.bm25_search"),
    ("Hybrid Fusion", "search.hybrid_fusion"),
    ("TF-IDF", "search.tfidf_search"),
    ("Word2Vec", "search.word2vec_search"),
    ("Serial Fusion", "search.serial_fusion_search"),     # أضفت هنا
    ("Parallel Fusion", "search.parallel_fusion_search"), # أضفت هنا
]

def main():
    query = input("🔎 أدخل استعلام البحث: ")

    for name, module_path in search_scripts:
        print(f"\n{'='*40}\n🧠 النموذج: {name}\n{'='*40}")
        try:
            module = importlib.import_module(module_path)
            if hasattr(module, "search"):
                results = module.search(query)
                for i, result in enumerate(results[:5], 1):
                    if isinstance(result, (list, tuple)) and len(result) >= 3:
                        doc_id, snippet, score = result[:3]
                        print(f"{i}. [{doc_id}] | {snippet[:100]}... (الدرجة: {score:.4f})")
                    else:
                        print(f"{i}. {result}")
            else:
                print("⚠️ لا توجد دالة search في هذا النموذج.")
        except Exception as e:
            print(f"❌ حدث خطأ في النموذج {name}: {e}")

if __name__ == "__main__":
    main()
