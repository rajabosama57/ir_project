import csv
import os

def load_queries(filepath):
    """تحميل الاستعلامات من ملف TSV"""
    queries = {}
    with open(filepath, encoding="utf-8") as f:
        reader = csv.DictReader(f, delimiter="\t")
        for row in reader:
            qid = row['query_id']
            queries[qid] = row['text']
    return queries

def load_qrels(filepath):
    """تحميل المستندات المرتبطة (qrels) مع اعتبار فقط المستندات ذات صلة relevance>0"""
    qrels = {}
    with open(filepath, encoding="utf-8") as f:
        reader = csv.DictReader(f, delimiter="\t")
        for row in reader:
            qid = row['query_id']
            docid = row['doc_id']
            rel = int(row.get('relevance', 0))
            if rel > 0:
                qrels.setdefault(qid, set()).add(docid)
    return qrels

def load_results(filepath):
    """تحميل نتائج الاسترجاع لكل استعلام"""
    results = {}
    with open(filepath, encoding="utf-8") as f:
        reader = csv.DictReader(f, delimiter="\t")
        for row in reader:
            qid = row['query_id']
            docid = row['doc_id']
            results.setdefault(qid, []).append(docid)
    return results

def precision_at_k(retrieved, relevant, k):
    retrieved_k = retrieved[:k]
    relevant_set = set(relevant)
    if not retrieved_k:
        return 0.0
    num_relevant = sum(1 for doc in retrieved_k if doc in relevant_set)
    return num_relevant / k

def recall_at_k(retrieved, relevant, k):
    relevant_set = set(relevant)
    if len(relevant_set) == 0:
        return 0.0
    retrieved_k = retrieved[:k]
    num_relevant = sum(1 for doc in retrieved_k if doc in relevant_set)
    return num_relevant / len(relevant_set)

def average_precision(retrieved, relevant):
    relevant_set = set(relevant)
    score_sum = 0.0
    hit_count = 0
    for i, docid in enumerate(retrieved, start=1):
        if docid in relevant_set:
            hit_count += 1
            score_sum += hit_count / i
    if hit_count == 0:
        return 0.0
    return score_sum / hit_count

def mean_average_precision(all_retrieved, all_relevant):
    ap_scores = []
    for qid in all_relevant.keys():
        retrieved = all_retrieved.get(qid, [])
        relevant = all_relevant[qid]
        ap = average_precision(retrieved, relevant)
        ap_scores.append(ap)
    if not ap_scores:
        return 0.0
    return sum(ap_scores) / len(ap_scores)

def evaluate(results, qrels, ks=[5, 10, 20]):
    precisions = {k: [] for k in ks}
    recalls = {k: [] for k in ks}
    map_score = mean_average_precision(results, qrels)

    for qid, relevant_docs in qrels.items():
        retrieved_docs = results.get(qid, [])

        for k in ks:
            precisions[k].append(precision_at_k(retrieved_docs, relevant_docs, k))
            recalls[k].append(recall_at_k(retrieved_docs, relevant_docs, k))

    avg_precisions = {k: sum(vals)/len(vals) if vals else 0.0 for k, vals in precisions.items()}
    avg_recalls = {k: sum(vals)/len(vals) if vals else 0.0 for k, vals in recalls.items()}

    return avg_precisions, avg_recalls, map_score

if __name__ == "__main__":
    queries_path = "data/cord19/queries.tsv"
    qrels_path = "data/cord19/qrels/qrels.tsv"

    print("[INFO] 📥 Loading queries and qrels...")
    queries = load_queries(queries_path)
    qrels = load_qrels(qrels_path)

    results_dir = "results"
    os.makedirs("reports", exist_ok=True)
    report_lines = []

    for filename in os.listdir(results_dir):
        if filename.endswith(".tsv"):
            print(f"\n[INFO] 🔍 Evaluating file: {filename}")
            results_path = os.path.join(results_dir, filename)
            results = load_results(results_path)

            precisions, recalls, map_score = evaluate(results, qrels)

            print(f"\n📊 [RESULTS] تقييم: {filename}")
            for k in sorted(precisions.keys()):
                print(f"Precision@{k}: {precisions[k]:.4f}")
                print(f"Recall@{k}: {recalls[k]:.4f}")
            print(f"Mean Average Precision (MAP): {map_score:.4f}")

            # حفظ النتائج للتقرير
            report_lines.append(f"📄 File: {filename}")
            for k in sorted(precisions.keys()):
                report_lines.append(f"  Precision@{k}: {precisions[k]:.4f}")
                report_lines.append(f"  Recall@{k}: {recalls[k]:.4f}")
            report_lines.append(f"  Mean Average Precision (MAP): {map_score:.4f}")
            report_lines.append("-" * 40)

    report_path = "reports/evaluation_report.txt"
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("\n".join(report_lines))

    print(f"\n✅ [INFO] تم حفظ التقرير الكامل في: {report_path}")
