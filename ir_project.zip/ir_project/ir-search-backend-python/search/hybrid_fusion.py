import os
import sys
import csv
from collections import defaultdict

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from search.tfidf_search import search as tfidf_search
from search.word2vec_search import search as w2v_search
from search.bm25_query import search as bm25_search
from search.bm25_query import fetch_document_texts


def normalize_scores(results):
    """Normalize scores between 0 and 1"""
    if not results:
        return {}
    scores = [score for _, score in results]
    max_score = max(scores)
    min_score = min(scores)
    if max_score == min_score:
        return {doc_id: 1.0 for doc_id, _ in results}
    return {doc_id: (score - min_score) / (max_score - min_score) for doc_id, score in results}


def hybrid_search(query, top_k=20, weights=None):
    """
    Perform hybrid search using TF-IDF, Word2Vec, and BM25
    :param query: نص الاستعلام
    :param top_k: عدد النتائج
    :param weights: dict يحتوي على الأوزان مثل {"tfidf": 0.4, "w2v": 0.3, "bm25": 0.3}
    """
    if weights is None:
        weights = {"tfidf": 0.4, "w2v": 0.3, "bm25": 0.3}

    print("[INFO] 🔄 Running individual search models...")
    tfidf_results = tfidf_search(query, top_k=50)
    w2v_results = w2v_search(query, top_k=50)
    bm25_results = bm25_search(query, top_k=50)

    tfidf_scores = normalize_scores(tfidf_results)
    w2v_scores = normalize_scores(w2v_results)
    bm25_scores = normalize_scores(bm25_results)

    print("[INFO] ⚖️ Fusing scores...")

    final_scores = defaultdict(float)
    for doc_id in set(list(tfidf_scores) + list(w2v_scores) + list(bm25_scores)):
        final_scores[doc_id] = (
            tfidf_scores.get(doc_id, 0) * weights["tfidf"] +
            w2v_scores.get(doc_id, 0) * weights["w2v"] +
            bm25_scores.get(doc_id, 0) * weights["bm25"]
        )

    sorted_docs = sorted(final_scores.items(), key=lambda x: x[1], reverse=True)[:top_k]
    return sorted_docs


def save_results_to_tsv(results, query, filename="hybrid_results.tsv"):
    """حفظ النتائج كاملة في ملف TSV داخل مجلد results"""
    os.makedirs("results", exist_ok=True)
    file_path = os.path.join("results", filename)

    with open(file_path, mode='w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f, delimiter='\t')
        # كتابة عنوان الأعمدة
        writer.writerow(['query', 'rank', 'doc_id', 'score'])
        for rank, (doc_id, score) in enumerate(results, start=1):
            writer.writerow([query, rank, doc_id, f"{score:.6f}"])
    print(f"[INFO] ✅ تم حفظ النتائج في الملف: {file_path}")


if __name__ == "__main__":
    query = input("📝 أدخل استعلامك: ")
    top_results = hybrid_search(query, top_k=20)  # جلب أفضل 20 نتيجة

    # عرض أفضل 5 نتائج فقط في الكونسول
    print("\n📄 أفضل 5 نتائج:\n")
    top_5 = top_results[:5]
    doc_ids_top_5 = [doc_id for doc_id, _ in top_5]
    doc_texts = fetch_document_texts(doc_ids_top_5)

    for rank, (doc_id, score) in enumerate(top_5, 1):
        text = doc_texts.get(doc_id, "نص غير متاح")
        print(f"{rank}. [{doc_id}] | 🔹 {text[:100]}... (درجة التشابه: {score:.4f})")

    # حفظ كامل النتائج العشرين في ملف TSV داخل مجلد results
    save_results_to_tsv(top_results, query)
