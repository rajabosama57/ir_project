import sys
import os
import csv

# إضافة مجلد المشروع الجذر إلى المسار
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

import json
from core.preprocessor import TextPreprocessor

# تهيئة المعالج النصي مرة واحدة
preproc = TextPreprocessor()

# تعريف دوال خاصة بالمعالجة (للتوحيد مع بقية الكود في المشروع)
def custom_tokenizer(text):
    tokens = preproc.tokenize(text)
    tokens = preproc.remove_stop_words(tokens)
    tokens = preproc.stem_tokens(tokens)
    return tokens

def custom_preprocessor(text):
    return preproc.normalize_text(text)

# تحميل الفهرس المعكوس من ملف JSON
def load_inverted_index(index_path="indexing/inverted_index.json"):
    print(f"[📦] جاري تحميل الفهرس المعكوس من: {index_path}")
    with open(index_path, "r", encoding="utf-8") as f:
        return json.load(f)

# البحث عن الوثائق التي تحتوي على جميع كلمات الاستعلام
def search_in_index(query, index):
    print(f"[🔍] معالجة الاستعلام: {query}")
    tokens = custom_tokenizer(query)
    print(f"[🪄] عدد الكلمات بعد المعالجة: {len(tokens)}")

    matching_docs = None
    for token in tokens:
        docs_with_token = set(index.get(token, []))
        if matching_docs is None:
            matching_docs = docs_with_token
        else:
            matching_docs &= docs_with_token  # تقاطع (AND)

    return sorted(matching_docs) if matching_docs else []

if __name__ == "__main__":
    index = load_inverted_index()
    user_query = input("🔎 أدخل استعلامك: ").strip()

    results = search_in_index(user_query, index)

    if results:
        print(f"\n✅ تم العثور على {len(results)} مستند/مستندات مطابقة:")
        for i, doc_id in enumerate(results[:10], start=1):  # عرض أول 10 فقط
            print(f"{i}. 📄 Doc ID: {doc_id}")

        # 📝 إنشاء مجلد النتائج إذا لم يكن موجودًا
        os.makedirs("results", exist_ok=True)

        # ✏️ حفظ النتائج في ملف CSV
        result_file = os.path.join("results", "inverted_results.csv")
        with open(result_file, "w", encoding="utf-8", newline='') as csvfile:
            writer = csv.writer(csvfile)
            # كتابة رأس الجدول
            writer.writerow(["Query", "Number of Results", "Doc ID"])
            # كتابة كل مستند في صف منفصل مع بيانات الاستعلام وعدد النتائج
            for doc_id in results:
                writer.writerow([user_query, len(results), doc_id])

        print(f"\n💾 تم حفظ النتائج في: {result_file}")

    else:
        print("\n⚠️ لم يتم العثور على مستندات مطابقة.")
