import os
import sys
import sqlite3
from rank_bm25 import BM25Okapi
from joblib import load
import csv

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from core.preprocessor import TextPreprocessor

preproc = TextPreprocessor()

def fetch_document_texts(doc_ids, db_path="db/ir_documents.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    placeholders = ','.join(['?'] * len(doc_ids))
    cursor.execute(f"SELECT doc_id, processed_text FROM documents WHERE doc_id IN ({placeholders})", doc_ids)
    data = cursor.fetchall()
    conn.close()
    return {doc_id: text for doc_id, text in data}

def search(query, model_dir="models"):
    print(f"[INFO] 🔍 Searching BM25 for: {query}")
    bm25 = load(os.path.join(model_dir, "bm25_model.joblib"))
    doc_ids = load(os.path.join(model_dir, "bm25_doc_ids.joblib"))

    query_tokens = preproc.tokenize(query)
    query_tokens = preproc.remove_stop_words(query_tokens)
    query_tokens = preproc.stem_tokens(query_tokens)

    scores = bm25.get_scores(query_tokens)
    # ترتيب كل النتائج بناءً على الدرجة
    ranked_results = sorted(
        zip(doc_ids, scores),
        key=lambda x: x[1],
        reverse=True
    )
    return ranked_results

if __name__ == "__main__":
    query = input("📝 أدخل استعلامك: ")
    all_results = search(query)

    # إنشاء مجلد النتائج إذا غير موجود
    os.makedirs("results", exist_ok=True)

    results_path = "results/bm25_results.tsv"

    # احفظ كل النتائج في ملف
    with open(results_path, "w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f, delimiter="\t")
        writer.writerow(["query_id", "doc_id"])
        for doc_id, score in all_results:
            writer.writerow([1, doc_id])  # استخدم query_id=1 مؤقتًا

    print(f"\n✅ [INFO] تم حفظ جميع النتائج في: {results_path}")

    # عرض أول top_k نتيجة فقط
    top_k = 5
    top_results = all_results[:top_k]

    doc_ids = [doc_id for doc_id, _ in top_results]
    doc_texts = fetch_document_texts(doc_ids)

    print("\n📄 أفضل النتائج:\n")
    for rank, (doc_id, score) in enumerate(top_results, 1):
        text = doc_texts.get(doc_id, "نص غير متاح")
        print(f"{rank}. [{doc_id}] | 🔹 {text[:100]}... (الدرجة: {score:.4f})")
