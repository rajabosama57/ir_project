import os
import sys
import sqlite3
from sklearn.metrics.pairwise import cosine_similarity
from joblib import load
from core.custom_functions import custom_preprocessor, custom_tokenizer

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from core.preprocessor import TextPreprocessor

preproc = TextPreprocessor()

def custom_tokenizer(text):
    tokens = preproc.tokenize(text)
    tokens = preproc.remove_stop_words(tokens)
    tokens = preproc.stem_tokens(tokens)
    return tokens

def custom_preprocessor(text):
    return preproc.normalize_text(text)

def load_vectorizer_and_data():
    print("[INFO] 🔄 Loading vectorizer and vectors from: models")
    # تأكد هنا أن الدوال موجودة قبل تحميل ال vectorizer
    vectorizer = load("models/tfidf_vectorizer.joblib")
    vectors = load("models/tfidf_vectors.joblib")
    doc_ids = load("models/doc_ids.joblib")
    return vectorizer, vectors, doc_ids

# بقية الكود كما هو

def fetch_document_texts(doc_ids, db_path):
    """
    جلب النصوص الأصلية للوثائق من قاعدة البيانات بناءً على doc_ids
    """
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    placeholders = ','.join(['?'] * len(doc_ids))
    cursor.execute(f"SELECT doc_id, processed_text FROM documents WHERE doc_id IN ({placeholders})", doc_ids)
    data = cursor.fetchall()
    conn.close()
    doc_map = {doc_id: text for doc_id, text in data}
    return doc_map

def search_tfidf(query, top_k, dataset_name):
    """
    الدالة الرئيسية للاستدعاء من API: بحث باستخدام TF-IDF
    """
    db_path = os.path.join("data", dataset_name, "ir_documents.db")


    # تحميل النماذج والبيانات
    vectorizer, doc_vectors, doc_ids = load_vectorizer_and_data()

    print(f"[INFO] 🔍 Searching for: {query}")

    # معالجة الاستعلام بنفس طريقة التدريب
    processed_query = custom_preprocessor(query)
    processed_query = ' '.join(custom_tokenizer(processed_query))

    # حساب التشابه
    query_vector = vectorizer.transform([processed_query])
    similarities = cosine_similarity(query_vector, doc_vectors).flatten()
    top_indices = similarities.argsort()[::-1][:top_k]

    # جلب نصوص الوثائق
    doc_ids_top = [doc_ids[idx] for idx in top_indices]
    doc_texts = fetch_document_texts(doc_ids_top, db_path)

    # تجهيز النتائج
    top_docs = []
    for rank, idx in enumerate(top_indices):
        doc_id = doc_ids[idx]
        score = similarities[idx]
        snippet = doc_texts.get(doc_id, "نص غير متاح")[:200]
        top_docs.append({
            "rank": rank + 1,
            "doc_id": doc_id,
            "score": float(score),
            "snippet": snippet
        })

    return top_docs
