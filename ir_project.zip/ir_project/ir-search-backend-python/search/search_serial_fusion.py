import os
import numpy as np
import sys
import csv
from sklearn.metrics.pairwise import cosine_similarity
from joblib import load

# إضافة مسار المشروع للوصول للموديولات
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from core.preprocessor import TextPreprocessor

preproc = TextPreprocessor()

# هذه الدوال مطلوبة للـ tfidf_vectorizer
def custom_preprocessor(text):
    return text

def custom_tokenizer(text):
    tokens = preproc.tokenize(text)
    tokens = preproc.remove_stop_words(tokens)
    tokens = preproc.stem_tokens(tokens)
    return tokens

def build_query_vector(query, tfidf_vectorizer, word2vec_model):
    tfidf_vec = tfidf_vectorizer.transform([query]).toarray()

    tokens = preproc.tokenize(query)
    tokens = preproc.remove_stop_words(tokens)
    tokens = preproc.stem_tokens(tokens)
    vectors = [word2vec_model.wv[token] for token in tokens if token in word2vec_model.wv]
    if vectors:
        w2v_vec = np.mean(vectors, axis=0).reshape(1, -1)
    else:
        w2v_vec = np.zeros((1, word2vec_model.vector_size))

    return np.hstack((tfidf_vec, w2v_vec))

def save_results(results, filename, append=True):
    os.makedirs("results", exist_ok=True)
    file_path = f"results/{filename}"
    mode = 'a' if append else 'w'
    file_exists = os.path.exists(file_path)

    with open(file_path, mode, newline='', encoding='utf-8') as f:
        writer = csv.writer(f, delimiter='\t')
        if not append or not file_exists:
            writer.writerow(['query_id', 'doc_id'])
        for query_id, docs in results.items():
            for doc_id in docs:
                writer.writerow([query_id, doc_id])
    print(f"[INFO] ✅ تم حفظ النتائج في {file_path}")

def search_serial_fusion(query, top_k=20):
    print("[🔍] Loading models and vectors...")
    tfidf_vectorizer = load("models/tfidf_vectorizer.joblib")
    word2vec_model = load("models/word2vec_model.joblib")
    fused_doc_vectors = load("fusion_models/serial_fusion_vectors.joblib")
    doc_ids = load("fusion_models/serial_fusion_doc_ids.joblib")

    print("[⚙️] Building query vector...")
    query_vec = build_query_vector(query, tfidf_vectorizer, word2vec_model)

    print("[📐] Calculating cosine similarity...")
    scores = cosine_similarity(query_vec, fused_doc_vectors)[0]

    ranked = sorted(zip(doc_ids, scores), key=lambda x: x[1], reverse=True)

    print(f"\n[🏁] أفضل 5 نتائج:")
    for rank, (doc_id, score) in enumerate(ranked[:5], 1):
        print(f"{rank}. Doc ID: {doc_id} | Score: {score:.4f}")

    return ranked[:top_k]

if __name__ == "__main__":
    user_query = input("🔎 أدخل استعلامك: ")

    top_results = search_serial_fusion(user_query, top_k=20)

    # توليد query_id متسلسل
    results_file = "results/serial_fusion_results.tsv"
    if os.path.exists(results_file):
        with open(results_file, encoding='utf-8') as f:
            reader = csv.reader(f, delimiter='\t')
            next(reader, None)  # تخطي الهيدر
            existing_query_ids = set(row[0] for row in reader)
            next_query_id = str(len(existing_query_ids) + 1)
    else:
        next_query_id = "1"

    # حفظ النتائج
    doc_ids_all = [doc_id for doc_id, _ in top_results]
    results = {next_query_id: doc_ids_all}
    save_results(results, "serial_fusion_results.tsv", append=True)
