import os
import sys
import sqlite3
import numpy as np
from gensim.models import Word2Vec
from sklearn.metrics.pairwise import cosine_similarity
from joblib import load
import csv

# المسار للوصول إلى preprocessor
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from core.preprocessor import TextPreprocessor

preproc = TextPreprocessor()

def preprocess_query(query):
    tokens = preproc.tokenize(query)
    tokens = preproc.remove_stop_words(tokens)
    tokens = preproc.stem_tokens(tokens)
    return tokens

def load_word2vec_model_and_vectors(model_dir="models"):
    print("[INFO] 🔄 Loading Word2Vec model and document vectors...")
    model = load(os.path.join(model_dir, "word2vec_model.joblib"))
    vectors = load(os.path.join(model_dir, "word2vec_vectors.joblib"))
    doc_ids = load(os.path.join(model_dir, "word2vec_doc_ids.joblib"))
    return model, np.array(vectors), doc_ids

def fetch_document_texts(doc_ids, db_path="db/ir_documents.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    placeholders = ','.join(['?'] * len(doc_ids))
    cursor.execute(f"SELECT doc_id, processed_text FROM documents WHERE doc_id IN ({placeholders})", doc_ids)
    data = cursor.fetchall()
    conn.close()
    return {doc_id: text for doc_id, text in data}

def embed_query(query_tokens, model, vector_size=100):
    vectors = [model.wv[word] for word in query_tokens if word in model.wv]
    if vectors:
        return np.mean(vectors, axis=0).reshape(1, -1)
    else:
        return np.zeros((1, vector_size))  # استعلام فارغ أو غير مفهوم

def search(query, top_k=20):
    model, doc_vectors, doc_ids = load_word2vec_model_and_vectors()
    query_tokens = preprocess_query(query)
    query_vector = embed_query(query_tokens, model, vector_size=model.vector_size)

    similarities = cosine_similarity(query_vector, doc_vectors).flatten()
    top_indices = similarities.argsort()[::-1][:top_k]

    top_docs = [(doc_ids[idx], similarities[idx]) for idx in top_indices]
    return top_docs

def save_results(results, filename, append=True):
    os.makedirs("results", exist_ok=True)
    file_path = f"results/{filename}"
    mode = 'a' if append else 'w'
    file_exists = os.path.exists(file_path)

    with open(file_path, mode, newline='', encoding='utf-8') as f:
        writer = csv.writer(f, delimiter='\t')
        if not append or not file_exists:
            writer.writerow(['query_id', 'doc_id'])
        for query_id, docs in results.items():
            for doc_id in docs:
                writer.writerow([query_id, doc_id])
    print(f"[INFO] ✅ تم حفظ النتائج في {file_path}")

if __name__ == "__main__":
    query = input("📝 أدخل استعلامك: ")
    top_results = search(query, top_k=20)  # نحفظ 20 نتيجة

    # عرض أفضل 5 نتائج فقط في الكونسول
    print("\n📄 أفضل 5 نتائج:\n")
    top_5 = top_results[:5]
    doc_ids_top_5 = [doc_id for doc_id, _ in top_5]
    doc_texts = fetch_document_texts(doc_ids_top_5)
    for rank, (doc_id, score) in enumerate(top_5, 1):
        text = doc_texts.get(doc_id, "نص غير متاح")
        print(f"{rank}. [{doc_id}] | 🔹 {text[:100]}... (درجة التشابه: {score:.4f})")

    # توليد query_id متسلسل
    results_file = "results/word2vec_results.tsv"
    if os.path.exists(results_file):
        with open(results_file, encoding='utf-8') as f:
            reader = csv.reader(f, delimiter='\t')
            next(reader, None)  # تخطي الهيدر
            existing_query_ids = set(row[0] for row in reader)
            next_query_id = str(len(existing_query_ids) + 1)
    else:
        next_query_id = "1"

    # حفظ كل نتائج البحث (20 نتيجة)
    doc_ids_all = [doc_id for doc_id, _ in top_results]
    results = {next_query_id: doc_ids_all}
    save_results(results, "word2vec_results.tsv", append=True)
