import os
import sys
import csv
import sqlite3
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
from joblib import load

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from core.preprocessor import TextPreprocessor

preproc = TextPreprocessor()

def fetch_document_texts(doc_ids, db_path="db/ir_documents.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    placeholders = ','.join(['?'] * len(doc_ids))
    cursor.execute(f"SELECT doc_id, processed_text FROM documents WHERE doc_id IN ({placeholders})", doc_ids)
    data = cursor.fetchall()
    conn.close()
    return {doc_id: text for doc_id, text in data}

def load_model_and_vectors(model_dir="models"):
    print("[INFO] 🔄 Loading BERT model and document vectors...")
    model = SentenceTransformer('all-MiniLM-L6-v2')
    vectors = load(os.path.join(model_dir, "bert_vectors.joblib"))
    doc_ids = load(os.path.join(model_dir, "bert_doc_ids.joblib"))
    return model, np.array(vectors), doc_ids

def search(query, top_k=5):
    model, doc_vectors, doc_ids = load_model_and_vectors()
    query_text = preproc.normalize_text(query)
    query_vector = model.encode([query_text])

    similarities = cosine_similarity(query_vector, doc_vectors).flatten()
    top_indices = similarities.argsort()[::-1][:top_k]

    return [(doc_ids[idx], similarities[idx]) for idx in top_indices]

def save_results(results, filename):
    os.makedirs("results", exist_ok=True)
    file_path = os.path.join("results", filename)
    file_exists = os.path.exists(file_path)

    with open(file_path, 'a', newline='', encoding='utf-8') as f:
        writer = csv.writer(f, delimiter='\t')
        # اكتب الهيدر فقط إذا كان الملف جديد
        if not file_exists:
            writer.writerow(['query_id', 'doc_id'])
        for query_id, doc_ids in results.items():
            for doc_id in doc_ids:
                writer.writerow([query_id, doc_id])
    print(f"[INFO] ✅ تم حفظ النتائج في {file_path}")

if __name__ == "__main__":
    query = input("📝 أدخل استعلامك: ")
    top_results = search(query, top_k=5)

    doc_ids = [doc_id for doc_id, _ in top_results]
    doc_texts = fetch_document_texts(doc_ids)

    print("\n📄 أفضل النتائج:\n")
    for rank, (doc_id, score) in enumerate(top_results, 1):
        text = doc_texts.get(doc_id, "نص غير متاح")
        print(f"{rank}. [{doc_id}] | 🔹 {text[:100]}... (درجة التشابه: {score:.4f})")

    # تحديد query_id بناءً على عدد الاستعلامات الموجودة في الملف
    results_file = "results/bert_results.tsv"
    if os.path.exists(results_file):
        with open(results_file, encoding='utf-8') as f:
            reader = csv.reader(f, delimiter='\t')
            next(reader, None)  # تخطي الهيدر
            existing_queries = set(row[0] for row in reader)
            next_query_id = str(len(existing_queries) + 1)
    else:
        next_query_id = "1"

    # حفظ النتائج
    results = {next_query_id: doc_ids}
    save_results(results, "bert_results.tsv")
