import sys
import os
from joblib import load

# أضف مجلد المشروع إلى المسار
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from core.preprocessor import TextPreprocessor

# تعريف المعالج النصي و الدوال الخاصة بالمعالجة
preproc = TextPreprocessor()

def custom_tokenizer(text):
    tokens = preproc.tokenize(text)
    tokens = preproc.remove_stop_words(tokens)
    tokens = preproc.stem_tokens(tokens)
    return tokens

def custom_preprocessor(text):
    return preproc.normalize_text(text)

# يجب تعريف هذه الدوال أو استيرادها قبل تحميل الـ TF-IDF vectorizer
# حتى لا يخطئ joblib في العثور عليها

# استيراد الدالة الخاصة بالبحث من parallel_fusion
from fusion.parallel_fusion import parallel_fusion_search

if __name__ == "__main__":
    # تحميل vectorizer بعد تعريف دالة المعالجة النصية
    from joblib import load
    tfidf_vectorizer = load("models/tfidf_vectorizer.joblib")

    user_query = input("🔎 أدخل استعلامك: ")
    parallel_fusion_search(user_query, top_k=5)
