import sqlite3
from typing import Optional

class DBManager:
    def __init__(self, db_path: str):
        self.conn = sqlite3.connect(db_path)
        self.cursor = self.conn.cursor()
        self.create_tables()
        self.ensure_columns()

    def create_tables(self):
        self.cursor.execute("""
           CREATE TABLE IF NOT EXISTS documents (
                doc_id TEXT PRIMARY KEY,
                title TEXT,
                abstract TEXT,
                original_text TEXT,
                processed_text TEXT
            )
        """)
        self.conn.commit()

    def add_column_if_not_exists(self, table_name: str, column_name: str, column_type: str):
        self.cursor.execute(f"PRAGMA table_info({table_name})")
        columns = [col[1] for col in self.cursor.fetchall()]
        if column_name not in columns:
            self.cursor.execute(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_type}")
            self.conn.commit()

    def ensure_columns(self):
        self.add_column_if_not_exists('documents', 'original_text', 'TEXT')
        self.add_column_if_not_exists('documents', 'processed_text', 'TEXT')

    def insert_document(self, doc_id: str, original_text: str, processed_text: Optional[str] = None):
        try:
            self.cursor.execute("""
                INSERT OR IGNORE INTO documents (doc_id, original_text)
                VALUES (?, ?)
            """, (doc_id, original_text))
            self.conn.commit()
            if processed_text:
                self.update_processed_text(doc_id, processed_text)
        except sqlite3.Error as e:
            print(f"Error inserting document {doc_id}: {e}")

    def update_processed_text(self, doc_id: str, processed_text: str):
        try:
            self.cursor.execute("""
                UPDATE documents SET processed_text = ? WHERE doc_id = ?
            """, (processed_text, doc_id))
            self.conn.commit()
        except sqlite3.Error as e:
            print(f"Error updating processed_text for document {doc_id}: {e}")

    def fetch_document(self, doc_id: str) -> Optional[dict]:
        self.cursor.execute("PRAGMA table_info(documents)")
        cols = [col[1] for col in self.cursor.fetchall()]
        self.cursor.execute(f"SELECT * FROM documents WHERE doc_id = ?", (doc_id,))
        row = self.cursor.fetchone()
        if row:
            return dict(zip(cols, row))
        return None

    def close(self):
        self.conn.close()
