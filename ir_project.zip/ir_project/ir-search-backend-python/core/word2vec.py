import os
import numpy as np
from gensim.models import Word2Vec
from core.db_manager import DBManager
from core.preprocessor import preprocess_text

class Word2VecEmbedder:
    def __init__(self, db_path='db/ir_documents.db', model_dir='models/'):
        self.db = DBManager(db_path)
        self.model_dir = model_dir
        os.makedirs(model_dir, exist_ok=True)
        self.model_path = os.path.join(model_dir, 'word2vec.model')
        self.vectors_path = os.path.join(model_dir, 'word2vec_vectors.npy')

    def train_and_save(self, vector_size=100, window=5, min_count=2, workers=4):
        docs = self.db.get_all_documents()
        tokenized_docs = [preprocess_text(doc)['tokens_no_stop'] for doc in docs]

        model = Word2Vec(sentences=tokenized_docs, vector_size=vector_size, window=window,
                         min_count=min_count, workers=workers)
        model.save(self.model_path)

        doc_vectors = []
        for tokens in tokenized_docs:
            word_vectors = [model.wv[token] for token in tokens if token in model.wv]
            if word_vectors:
                doc_vector = np.mean(word_vectors, axis=0)
            else:
                doc_vector = np.zeros(vector_size)
            doc_vectors.append(doc_vector)

        np.save(self.vectors_path, np.array(doc_vectors))

    def load_model(self):
        return Word2Vec.load(self.model_path)

    def load_vectors(self):
        return np.load(self.vectors_path)
