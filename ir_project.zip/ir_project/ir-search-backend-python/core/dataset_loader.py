import ir_datasets
import os
import csv

def save_tsv(filepath, rows, header=None):
    with open(filepath, 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f, delimiter='\t')
        if header:
            writer.writerow(header)
        writer.writerows(rows)

def save_qrels(dataset, qrels_dir):
    os.makedirs(qrels_dir, exist_ok=True)
    qrels = list(dataset.qrels_iter())
    qrel_file = os.path.join(qrels_dir, "qrels.tsv")
    with open(qrel_file, 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f, delimiter='\t')
        writer.writerow(['query_id', 'iteration', 'doc_id', 'relevance'])
        for qrel in qrels:
            writer.writerow([qrel.query_id, qrel.iteration, qrel.doc_id, qrel.relevance])

def prepare_msmarco_passage(output_dir='data/msmarco-passage', max_docs=300000):
    print("[INFO] Loading MSMARCO Passage dataset...")
    dataset = ir_datasets.load("msmarco-passage")
    os.makedirs(output_dir, exist_ok=True)

    docs = dataset.docs_iter()
    rows = []
    count = 0
    for doc in docs:
        rows.append([doc.doc_id, doc.text])
        count += 1
        if count >= max_docs:
            break
    save_tsv(os.path.join(output_dir, 'documents.tsv'), rows, header=['doc_id', 'text'])
    print(f"[INFO] Saved {count} documents to documents.tsv")

    queries = list(dataset.queries_iter())
    queries_rows = [[q.query_id, q.text] for q in queries]
    save_tsv(os.path.join(output_dir, 'queries.tsv'), queries_rows, header=['query_id', 'text'])
    print(f"[INFO] Saved {len(queries_rows)} queries to queries.tsv")

    save_qrels(dataset, os.path.join(output_dir, 'qrels'))
    print(f"[INFO] Saved qrels")

def prepare_cord19(output_dir='data/cord19'):
    print("[INFO] Loading CORD-19 dataset...")
    dataset = ir_datasets.load("cord19")
    os.makedirs(output_dir, exist_ok=True)

    docs = list(dataset.docs_iter())
    with open(os.path.join(output_dir, 'metadata.csv'), 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['doc_id', 'title', 'authors', 'abstract', 'body'])
        for doc in docs:
            writer.writerow([
                doc.doc_id,
                getattr(doc, 'title', ''),
                getattr(doc, 'authors', ''),
                getattr(doc, 'abstract', ''),
                getattr(doc, 'body', '')
            ])
    print(f"[INFO] Saved {len(docs)} documents to metadata.csv")

    save_qrels(dataset, os.path.join(output_dir, 'qrels'))
    print(f"[INFO] Saved qrels")

if __name__ == "__main__":
    prepare_msmarco_passage()
    prepare_cord19()
