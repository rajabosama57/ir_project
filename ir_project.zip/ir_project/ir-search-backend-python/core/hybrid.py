# core/hybrid.py

import numpy as np
import joblib
import os
from sklearn.preprocessing import normalize

from core.bert_embedder import BERTEmbedder
from core.tfidf import TFIDFVectorizer
from core.db_manager import DBManager
from core.preprocessor import preprocess_text


class HybridRetriever:
    def __init__(self, db_path='db/ir_documents.db', save_path='vectors/hybrid'):
        self.db = DBManager(db_path)
        self.tfidf = TFIDFVectorizer()
        self.bert = BERTEmbedder()
        self.save_path = save_path
        os.makedirs(save_path, exist_ok=True)

        # تحميل التمثيلات
        self.tfidf_matrix = joblib.load('vectors/tfidf/tfidf_matrix.pkl')
        self.tfidf_vectorizer = joblib.load('vectors/tfidf/vectorizer.pkl')
        self.doc_ids = joblib.load('vectors/tfidf/doc_ids.pkl')
        self.bert_vectors = joblib.load('vectors/bert/bert_vectors.pkl')

    def hybrid_search(self, query, top_k=5, alpha=0.5):
        """
        دمج بين تمثيل BERT و TF-IDF
        alpha: نسبة مساهمة BERT (0.5 = توازن بين الاثنين)
        """
        # تمثيل الاستعلام
        query_processed = preprocess_text(query)['final_text']
        tfidf_query_vec = self.tfidf_vectorizer.transform([query_processed])
        bert_query_vec = self.bert.encode(query)

        # تطبيع
        tfidf_query_vec = normalize(tfidf_query_vec)
        tfidf_matrix = normalize(self.tfidf_matrix)

        bert_query_vec = normalize(bert_query_vec.reshape(1, -1))
        bert_doc_matrix = normalize(self.bert_vectors)

        # حساب التشابه
        tfidf_scores = np.dot(tfidf_matrix, tfidf_query_vec.T).ravel()
        bert_scores = np.dot(bert_doc_matrix, bert_query_vec.T).ravel()

        # دمج الدرجات
        combined_scores = alpha * bert_scores + (1 - alpha) * tfidf_scores
        top_indices = combined_scores.argsort()[::-1][:top_k]

        results = [(self.doc_ids[i], float(combined_scores[i])) for i in top_indices]
        return results


if __name__ == "__main__":
    retriever = HybridRetriever()
    query = "Vaccine for covid"
    results = retriever.hybrid_search(query, top_k=5)

    print("\nTop Hybrid Results:")
    for doc_id, score in results:
        print(f"Doc ID: {doc_id} | Score: {score:.4f}")
