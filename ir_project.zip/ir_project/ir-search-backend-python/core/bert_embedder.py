# core/bert_embedder.py

import os
import joblib
import numpy as np
from tqdm import tqdm
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

from core.db_manager import DBManager
from core.preprocessor import preprocess_text


class BERTEmbedder:
    def __init__(self, model_name='all-MiniLM-L6-v2', db_path='db/ir_documents.db', save_path='vectors/bert'):
        self.model = SentenceTransformer(model_name)
        self.db = DBManager(db_path)
        self.save_path = save_path
        os.makedirs(save_path, exist_ok=True)
        self.vector_file = os.path.join(save_path, 'bert_vectors.pkl')
        self.doc_ids_file = os.path.join(save_path, 'bert_doc_ids.pkl')

    def build_embeddings(self, dataset_name):
        """
        تبني تمثيل BERT لجميع الوثائق داخل مجموعة البيانات المحددة
        """
        print(f"Extracting documents from: {dataset_name}")
        documents = self.db.get_documents(dataset_name)
        doc_ids = []
        embeddings = []

        for doc_id, text in tqdm(documents):
            processed = preprocess_text(text)
            emb = self.model.encode(processed['final_text'])
            doc_ids.append(doc_id)
            embeddings.append(emb)

        embeddings = np.array(embeddings)
        joblib.dump(embeddings, self.vector_file)
        joblib.dump(doc_ids, self.doc_ids_file)

        print(f"[✓] Saved BERT embeddings for {len(doc_ids)} documents")

    def load_embeddings(self):
        vectors = joblib.load(self.vector_file)
        doc_ids = joblib.load(self.doc_ids_file)
        return doc_ids, vectors

    def search(self, query, top_k=5):
        """
        استرجاع أفضل top_k وثائق مشابهة للاستعلام بناءً على تمثيل BERT
        """
        doc_ids, doc_vectors = self.load_embeddings()
        query_processed = preprocess_text(query)
        query_vec = self.model.encode(query_processed['final_text']).reshape(1, -1)

        scores = cosine_similarity(query_vec, doc_vectors)[0]
        top_indices = np.argsort(scores)[::-1][:top_k]

        results = [(doc_ids[i], float(scores[i])) for i in top_indices]
        return results


if __name__ == "__main__":
    bert = BERTEmbedder()
    bert.build_embeddings("msmarco")  # أو cord19

    query = "What is the role of vaccines in pandemic prevention?"
    results = bert.search(query)
    print("\nTop Results:")
    for doc_id, score in results:
        print(f"Doc ID: {doc_id} | Score: {score:.4f}")
