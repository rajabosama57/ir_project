import re
import nltk
nltk.data.path.append('./nltk_data')  # ⭐

from nltk.stem import PorterStemmer, WordNetLemmatizer
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords, wordnet
from nltk import pos_tag

# تحميل الموارد اللازمة مرة واحدة (تشغيل مرة واحدة فقط)
# nltk.download('punkt')
# nltk.download('stopwords')
# nltk.download('wordnet')
# nltk.download('averaged_perceptron_tagger')

ps = PorterStemmer()
lemmatizer = WordNetLemmatizer()
EN_STOPWORDS = set(stopwords.words('english'))

def get_wordnet_pos(treebank_tag):
    """تحويل علامات POS من تنسيق POS Tagger إلى تنسيق WordNet"""
    if treebank_tag.startswith('J'):
        return wordnet.ADJ
    elif treebank_tag.startswith('V'):
        return wordnet.VERB
    elif treebank_tag.startswith('N'):
        return wordnet.NOUN
    elif treebank_tag.startswith('R'):
        return wordnet.ADV
    else:
        return wordnet.NOUN  # الافتراضي

class TextPreprocessor:
    def __init__(self, use_stemming=False, use_lemmatization=True, remove_stopwords=True):
        self.use_stemming = use_stemming
        self.use_lemmatization = use_lemmatization
        self.remove_stopwords = remove_stopwords

    def normalize_text(self, text: str) -> str:
        text = text.lower()
        text = re.sub(r'[^\w\s]', '', text)
        text = re.sub(r'\d+', '', text)
        return text.strip()

    def tokenize(self, text: str) -> list[str]:
        normalized = self.normalize_text(text)
        tokens = word_tokenize(normalized)
        return tokens

    def remove_stop_words(self, tokens: list[str]) -> list[str]:
        if not self.remove_stopwords:
            return tokens
        return [token for token in tokens if token not in EN_STOPWORDS]

    def stem_tokens(self, tokens: list[str]) -> list[str]:
        if not self.use_stemming:
            return tokens
        return [ps.stem(token) for token in tokens]

    def lemmatize_tokens(self, tokens: list[str]) -> list[str]:
        if not self.use_lemmatization:
            return tokens
        pos_tags = pos_tag(tokens)
        lemmatized = [lemmatizer.lemmatize(token, get_wordnet_pos(pos)) for token, pos in pos_tags]
        return lemmatized

    def preprocess(self, text: str) -> dict:
        normalized = self.normalize_text(text)
        tokens = self.tokenize(text)
        tokens_no_stop = self.remove_stop_words(tokens)
        if self.use_lemmatization:
            processed_tokens = self.lemmatize_tokens(tokens_no_stop)
        elif self.use_stemming:
            processed_tokens = self.stem_tokens(tokens_no_stop)
        else:
            processed_tokens = tokens_no_stop

        final_text = ' '.join(processed_tokens)

        return {
            'normalized': normalized,
            'tokens': tokens,
            'tokens_no_stop': tokens_no_stop,
            'processed_tokens': processed_tokens,
            'final_text': final_text
        }

if __name__ == "__main__":
    preproc = TextPreprocessor(use_stemming=False, use_lemmatization=True)
    sample_text = "The 12 striped 576bats ,>are }hanging {on their feet for best."
    result = preproc.preprocess(sample_text)
    print("Normalized:", result['normalized'])
    print("Tokens:", result['tokens'])
    print("Tokens without stopwords:", result['tokens_no_stop'])
    print("Processed tokens (lemmatized or stemmed):", result['processed_tokens'])
    print("Final processed text:", result['final_text'])
