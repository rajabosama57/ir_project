import os
import joblib
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from core.db_manager import DBManager
from core.preprocessor import preprocess_text

class TFIDFEmbedder:
    def __init__(self, db_path='db/ir_documents.db', model_dir='models/'):
        self.db = DBManager(db_path)
        self.model_dir = model_dir
        os.makedirs(model_dir, exist_ok=True)
        self.vectorizer_path = os.path.join(model_dir, 'tfidf_vectorizer.joblib')
        self.vectors_path = os.path.join(model_dir, 'tfidf_vectors.npy')

    def train_and_save(self):
        docs = self.db.get_all_documents()
        processed_texts = [preprocess_text(doc)['final_text'] for doc in docs]
        
        vectorizer = TfidfVectorizer()
        vectors = vectorizer.fit_transform(processed_texts)
        
        joblib.dump(vectorizer, self.vectorizer_path)
        np.save(self.vectors_path, vectors.toarray())

    def load_vectorizer(self):
        return joblib.load(self.vectorizer_path)

    def load_vectors(self):
        return np.load(self.vectors_path)
