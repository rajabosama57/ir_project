# core/bm25.py

import joblib
import os
from tqdm import tqdm
from rank_bm25 import BM25Okapi

from core.db_manager import DBManager
from core.preprocessor import preprocess_text


class BM25Retriever:
    def __init__(self, db_path='db/ir_documents.db', save_path='vectors/bm25'):
        self.db = DBManager(db_path)
        self.save_path = save_path
        os.makedirs(save_path, exist_ok=True)
        self.bm25_file = os.path.join(save_path, 'bm25_instance.pkl')
        self.doc_ids_file = os.path.join(save_path, 'bm25_doc_ids.pkl')
        self.tokenized_corpus = []
        self.doc_ids = []

    def build_bm25(self, dataset_name):
        print(f"Loading documents from: {dataset_name}")
        documents = self.db.get_documents(dataset_name)

        self.tokenized_corpus = []
        self.doc_ids = []

        for doc_id, text in tqdm(documents):
            processed = preprocess_text(text)
            tokens = processed['tokens_no_stop']
            self.tokenized_corpus.append(tokens)
            self.doc_ids.append(doc_id)

        bm25 = BM25Okapi(self.tokenized_corpus)

        joblib.dump(bm25, self.bm25_file)
        joblib.dump(self.doc_ids, self.doc_ids_file)

        print(f"[✓] BM25 index built and saved for {len(self.doc_ids)} documents.")

    def load_bm25(self):
        bm25 = joblib.load(self.bm25_file)
        doc_ids = joblib.load(self.doc_ids_file)
        return bm25, doc_ids

    def search(self, query, top_k=5):
        bm25, doc_ids = self.load_bm25()
        query_processed = preprocess_text(query)
        query_tokens = query_processed['tokens_no_stop']

        scores = bm25.get_scores(query_tokens)
        ranked_indices = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:top_k]

        results = [(doc_ids[i], float(scores[i])) for i in ranked_indices]
        return results


if __name__ == "__main__":
    bm25 = BM25Retriever()
    bm25.build_bm25("msmarco")  # أو cord19

    query = "What is coronavirus treatment?"
    results = bm25.search(query)

    print("\nTop BM25 Results:")
    for doc_id, score in results:
        print(f"Doc ID: {doc_id} | Score: {score:.4f}")
