import os
import sys
import sqlite3
from sklearn.feature_extraction.text import TfidfVectorizer
from joblib import dump

# أضف مجلد المشروع إلى المسار
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from core.preprocessor import TextPreprocessor

# أنشئ نسخة واحدة فقط من المعالج
preproc = TextPreprocessor()

def custom_tokenizer(text):
    tokens = preproc.tokenize(text)
    tokens = preproc.remove_stop_words(tokens)
    tokens = preproc.stem_tokens(tokens)
    return tokens

def custom_preprocessor(text):
    return preproc.normalize_text(text)

def load_documents(db_path: str):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # استرجع original_text بدل processed_text مؤقتًا
    cursor.execute("SELECT doc_id, processed_text FROM documents WHERE processed_text IS NOT NULL AND processed_text != ''")
    data = cursor.fetchall()
    conn.close()
    return data


def build_and_save_tfidf_model(db_path: str, output_dir="models"):
    print("[INFO] 🔄 Loading documents...")
    data = load_documents(db_path)
    if not data:
        print("[ERROR] ❌ No data found in the database!")
        return

    doc_ids, texts = zip(*data)

    print("[INFO] 📊 Building TF-IDF vectorizer...")
    vectorizer = TfidfVectorizer(
        tokenizer=custom_tokenizer,
        preprocessor=custom_preprocessor,
        lowercase=False
    )
    vectors = vectorizer.fit_transform(texts)

    os.makedirs(output_dir, exist_ok=True)

    print("[INFO] 💾 Saving vectorizer and vectors to disk...")
    dump(vectorizer, os.path.join(output_dir, "tfidf_vectorizer.joblib"))
    dump(vectors, os.path.join(output_dir, "tfidf_vectors.joblib"))
    dump(doc_ids, os.path.join(output_dir, "doc_ids.joblib"))
    dump(vectorizer.get_feature_names_out(), os.path.join(output_dir, "tfidf_features.joblib"))

    print("[INFO] ✅ TF-IDF vectorizer and vectors saved successfully.")

# ✅ هذا ضروري حتى يعمل السكربت عند تنفيذه
if __name__ == "__main__":
    build_and_save_tfidf_model("db/ir_documents.db")
