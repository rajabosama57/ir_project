# import os
# import sys
# import sqlite3
# from sentence_transformers import SentenceTransformer
# import numpy as np
# from joblib import dump

# sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
# from core.preprocessor import TextPreprocessor

# preproc = TextPreprocessor()

# def load_documents(db_path: str):
#     conn = sqlite3.connect(db_path)
#     cursor = conn.cursor()
#     cursor.execute("SELECT doc_id, original_text FROM documents WHERE original_text IS NOT NULL AND original_text != ''")
#     data = cursor.fetchall()
#     conn.close()
#     return data

# def build_and_save_bert_embeddings(db_path="db/ir_documents.db", output_dir="models"):
#     print("[INFO] 🔄 Loading documents...")
#     data = load_documents(db_path)
#     if not data:
#         print("[ERROR] ❌ No documents found.")
#         return

#     doc_ids, texts = zip(*data)
#     texts = [preproc.normalize_text(text) for text in texts]

#     print("[INFO] 🧠 Loading BERT model...")
#     model = SentenceTransformer('all-MiniLM-L6-v2')

#     print("[INFO] 🔍 Generating embeddings...")
#     embeddings = model.encode(texts, show_progress_bar=True)

#     os.makedirs(output_dir, exist_ok=True)
#     dump(model, os.path.join(output_dir, "bert_model.joblib"))
#     dump(embeddings, os.path.join(output_dir, "bert_vectors.joblib"))
#     dump(doc_ids, os.path.join(output_dir, "bert_doc_ids.joblib"))

#     print("[INFO] ✅ BERT embeddings saved.")

# if __name__ == "__main__":
#     build_and_save_bert_embeddings()

import os
import sys
import sqlite3
from sentence_transformers import SentenceTransformer
import numpy as np
from joblib import dump, load
import torch

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from core.preprocessor import TextPreprocessor

preproc = TextPreprocessor()

def load_documents(db_path: str, limit: int = None):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    query = "SELECT doc_id, original_text FROM documents WHERE original_text IS NOT NULL AND original_text != ''"
    if limit:
        query += f" LIMIT {limit}"
    cursor.execute(query)
    data = cursor.fetchall()
    conn.close()
    return data

def build_and_save_bert_embeddings(db_path="db/ir_documents.db", output_dir="models", limit=None, batch_size=256):
    print("[INFO] 🔄 Loading documents...")
    data = load_documents(db_path, limit)
    if not data:
        print("[ERROR] ❌ No documents found.")
        return

    doc_ids, texts = zip(*data)
    texts = [preproc.normalize_text(text) for text in texts]

    os.makedirs(output_dir, exist_ok=True)
    vec_path = os.path.join(output_dir, "bert_vectors_partial.npy")
    id_path = os.path.join(output_dir, "bert_doc_ids_partial.npy")

    # Check for existing progress
    if os.path.exists(vec_path) and os.path.exists(id_path):
        existing_embeddings = list(np.load(vec_path, allow_pickle=True))
        existing_ids = list(np.load(id_path, allow_pickle=True))
        start_idx = len(existing_embeddings)
        print(f"[INFO] 🔁 Resuming from {start_idx}/{len(texts)}")
    else:
        existing_embeddings = []
        existing_ids = []
        start_idx = 0

    print("[INFO] 🧠 Loading BERT model...")
    model = SentenceTransformer('all-MiniLM-L6-v2')
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = model.to(device)
    print(f"[INFO] 🚀 Using device: {device}")

    print("[INFO] 🔍 Generating embeddings in batches...")
    for i in range(start_idx, len(texts), batch_size):
        batch_texts = texts[i:i+batch_size]
        batch_ids = doc_ids[i:i+batch_size]

        try:
            batch_embeddings = model.encode(batch_texts, show_progress_bar=False, convert_to_numpy=True)
        except Exception as e:
            print(f"[ERROR] ⚠️ Failed batch {i}-{i+batch_size}: {e}")
            continue

        existing_embeddings.extend(batch_embeddings)
        existing_ids.extend(batch_ids)

        # Save partial progress
        np.save(vec_path, np.array(existing_embeddings, dtype=object))
        np.save(id_path, np.array(existing_ids, dtype=object))

        print(f"[INFO] ✅ Processed {i + len(batch_texts)} / {len(texts)}")

    # Save final model
    dump(model, os.path.join(output_dir, "bert_model.joblib"))
    dump(np.array(existing_embeddings), os.path.join(output_dir, "bert_vectors.joblib"))
    dump(np.array(existing_ids), os.path.join(output_dir, "bert_doc_ids.joblib"))

    print("[INFO] 🧠 BERT embeddings generation completed and saved.")

if __name__ == "__main__":
    # يمكنك تعديل limit لتجربة عدد أقل من الوثائق
    build_and_save_bert_embeddings(limit=50)  # limit=500 مثلاً للتجربة
