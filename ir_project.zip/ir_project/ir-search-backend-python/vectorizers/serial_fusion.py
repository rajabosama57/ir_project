import os
import numpy as np
from joblib import load, dump
from scipy.sparse import csr_matrix, hstack

def load_vectors_and_ids(tfidf_path, w2v_path, tfidf_ids_path, w2v_ids_path):
    tfidf_vectors = load(tfidf_path)
    w2v_vectors = load(w2v_path)
    tfidf_ids = load(tfidf_ids_path)
    w2v_ids = load(w2v_ids_path)

    print(f"[DEBUG] TF-IDF doc_ids sample: {tfidf_ids[:5]}")
    print(f"[DEBUG] Word2Vec doc_ids sample: {w2v_ids[:5]}")
    print(f"[DEBUG] Length TF-IDF IDs: {len(tfidf_ids)}, Length Word2Vec IDs: {len(w2v_ids)}")

    return tfidf_vectors, w2v_vectors, tfidf_ids, w2v_ids

def align_vectors(tfidf_vecs, tfidf_ids, w2v_vecs, w2v_ids):
    w2v_id_to_index = {doc_id: idx for idx, doc_id in enumerate(w2v_ids)}

    tfidf_indices = []
    w2v_indices = []
    aligned_doc_ids = []

    for i, doc_id in enumerate(tfidf_ids):
        if doc_id in w2v_id_to_index:
            tfidf_indices.append(i)
            w2v_indices.append(w2v_id_to_index[doc_id])
            aligned_doc_ids.append(doc_id)

    tfidf_aligned = tfidf_vecs[tfidf_indices]
    w2v_aligned = np.array([w2v_vecs[i] for i in w2v_indices])
    aligned_doc_ids = np.array(aligned_doc_ids)

    print(f"[DEBUG] After alignment, number of docs: {len(aligned_doc_ids)}")

    return tfidf_aligned, w2v_aligned, aligned_doc_ids

def serial_fusion(tfidf_vectors, w2v_vectors):
    # تحويل Word2Vec إلى مصفوفة sparse بنفس شكل tfidf
    w2v_sparse = csr_matrix(w2v_vectors)
    fused_sparse = hstack([tfidf_vectors, w2v_sparse])
    return fused_sparse

def save_fusion(fused_vectors, doc_ids, output_dir="fusion_models"):
    os.makedirs(output_dir, exist_ok=True)
    dump(fused_vectors, os.path.join(output_dir, "serial_fusion_vectors.joblib"))
    dump(doc_ids, os.path.join(output_dir, "serial_fusion_doc_ids.joblib"))
    print("[INFO] ✅ Serial fusion vectors and doc IDs saved.")

if __name__ == "__main__":
    tfidf_vectors_path = "models/tfidf_vectors.joblib"
    w2v_vectors_path = "models/word2vec_vectors.joblib"
    tfidf_doc_ids_path = "models/doc_ids.joblib"
    w2v_doc_ids_path = "models/word2vec_doc_ids.joblib"

    print("[INFO] 🔄 Loading vectors and IDs...")
    tfidf_vecs, w2v_vecs, tfidf_ids, w2v_ids = load_vectors_and_ids(
        tfidf_vectors_path, w2v_vectors_path, tfidf_doc_ids_path, w2v_doc_ids_path
    )

    print("[INFO] 🔗 Aligning vectors based on common document IDs...")
    tfidf_vecs_aligned, w2v_vecs_aligned, aligned_doc_ids = align_vectors(
        tfidf_vecs, tfidf_ids, w2v_vecs, w2v_ids
    )

    print("[INFO] 🔀 Fusing vectors serially...")
    fused = serial_fusion(tfidf_vecs_aligned, w2v_vecs_aligned)

    save_fusion(fused, aligned_doc_ids)
