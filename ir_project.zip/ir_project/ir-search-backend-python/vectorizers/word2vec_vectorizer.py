import os
import sys
import sqlite3
from gensim.models import Word2Vec
from joblib import dump
import numpy as np

# إضافة المسار للوصول إلى preprocessor
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from core.preprocessor import TextPreprocessor

preproc = TextPreprocessor()

def load_documents(db_path: str):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT doc_id, original_text FROM documents WHERE original_text IS NOT NULL AND original_text != ''")
    data = cursor.fetchall()
    conn.close()
    return data

def preprocess_for_word2vec(text):
    tokens = preproc.tokenize(text)
    tokens = preproc.remove_stop_words(tokens)
    tokens = preproc.stem_tokens(tokens)
    return tokens

def build_and_save_word2vec(db_path: str, output_dir="models"):
    print("[INFO] 🔄 Loading and preprocessing documents...")
    data = load_documents(db_path)
    if not data:
        print("[ERROR] ❌ No documents found!")
        return

    doc_ids, texts = zip(*data)
    tokenized_docs = [preprocess_for_word2vec(text) for text in texts]

    print("[INFO] 🧠 Training Word2Vec model...")
    model = Word2Vec(
        sentences=tokenized_docs,
        vector_size=100,
        window=5,
        min_count=2,
        workers=4,
        sg=1  # skip-gram
    )

    print("[INFO] 📐 Building document embeddings...")
    doc_embeddings = []
    for tokens in tokenized_docs:
        vectors = [model.wv[word] for word in tokens if word in model.wv]
        if vectors:
            doc_vector = np.mean(vectors, axis=0)
        else:
            doc_vector = np.zeros(model.vector_size)
        doc_embeddings.append(doc_vector)

    os.makedirs(output_dir, exist_ok=True)
    dump(model, os.path.join(output_dir, "word2vec_model.joblib"))
    dump(doc_embeddings, os.path.join(output_dir, "word2vec_vectors.joblib"))
    dump(doc_ids, os.path.join(output_dir, "word2vec_doc_ids.joblib"))

    print("[INFO] ✅ Word2Vec model and vectors saved.")

if __name__ == "__main__":
    build_and_save_word2vec("db/ir_documents.db")
