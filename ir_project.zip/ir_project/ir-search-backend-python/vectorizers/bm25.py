import os
import sys
import sqlite3
from rank_bm25 import BM25Okapi
from joblib import dump, load

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from core.preprocessor import TextPreprocessor

preproc = TextPreprocessor()

def load_documents(db_path="db/ir_documents.db"):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT doc_id, original_text FROM documents WHERE original_text IS NOT NULL AND original_text != ''")
    data = cursor.fetchall()
    conn.close()
    return data

def preprocess_corpus(data):
    tokenized_corpus = []
    doc_ids = []
    for i, (doc_id, text) in enumerate(data, 1):
        tokens = preproc.tokenize(text)
        tokens = preproc.remove_stop_words(tokens)
        tokens = preproc.stem_tokens(tokens)
        tokenized_corpus.append(tokens)
        doc_ids.append(doc_id)
        if i % 10000 == 0:
            print(f"[INFO] تم معالجة {i} مستندات...")
    return doc_ids, tokenized_corpus

def build_and_save_bm25_model(db_path="db/ir_documents.db", output_dir="models"):
    print("[INFO] 🔄 Loading and preprocessing documents for BM25...")
    data = load_documents(db_path)
    if not data:
        print("[ERROR] ❌ No documents found.")
        return

    doc_ids, tokenized_corpus = preprocess_corpus(data)
    bm25 = BM25Okapi(tokenized_corpus)

    os.makedirs(output_dir, exist_ok=True)
    dump(bm25, os.path.join(output_dir, "bm25_model.joblib"))
    dump(doc_ids, os.path.join(output_dir, "bm25_doc_ids.joblib"))

    print("[INFO] ✅ BM25 model built and saved.")

if __name__ == "__main__":
    build_and_save_bm25_model()
