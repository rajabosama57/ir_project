import os
import sys
from fastapi import FastAPI, Query
from pydantic import BaseModel
from joblib import load
from sklearn.metrics.pairwise import cosine_similarity

# إضافة المسار للوصول إلى preprocessor
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from core.preprocessor import TextPreprocessor

# تعريف المعالج يدويًا
preproc = TextPreprocessor()

# تحميل النموذج والبيانات
MODEL_DIR = "models"
vectorizer = load(os.path.join(MODEL_DIR, "tfidf_vectorizer.joblib"))
vectors = load(os.path.join(MODEL_DIR, "tfidf_vectors.joblib"))
doc_ids = load(os.path.join(MODEL_DIR, "doc_ids.joblib"))

# FastAPI app
app = FastAPI(
    title="TF-IDF Search API",
    description="🔍 API للبحث باستخدام TF-IDF",
    version="1.0.0"
)

class SearchRequest(BaseModel):
    query: str
    top_k: int = 5

def preprocess_query(query: str):
    # معالجة الاستعلام يدويًا بنفس طريقة التدريب
    norm = preproc.normalize_text(query)
    tokens = preproc.tokenize(norm)
    tokens = preproc.remove_stop_words(tokens)
    tokens = preproc.stem_tokens(tokens)
    return " ".join(tokens)

@app.get("/")
def root():
    return {"message": "✅ API تعمل!"}

@app.post("/search")
def search_docs(request: SearchRequest):
    # 1️⃣ المعالجة اليدوية
    processed_query = preprocess_query(request.query)

    # 2️⃣ التحويل إلى vector
    query_vector = vectorizer.transform([processed_query])

    # 3️⃣ حساب التشابه
    similarities = cosine_similarity(query_vector, vectors).flatten()
    top_indices = similarities.argsort()[::-1][:request.top_k]

    results = []
    for idx in top_indices:
        results.append({
            "doc_id": doc_ids[idx],
            "score": float(similarities[idx])
        })

    return {"query": request.query, "results": results}
