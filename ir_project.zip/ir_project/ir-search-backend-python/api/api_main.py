from fastapi import FastAPI
from pydantic import BaseModel
import traceback
from fastapi import HTTPException
# استيراد دوال البحث من الملفات المختلفة
# from search.tfidf_search import search_tfidf
# from search.bert_search import search_bert
# from search.bm25_search import search_bm25
# from search.word2vec_search import search_word2vec
# لو عندك المزيد استوردها أيضًا
from search.word2vec_search import search_word2vec

# استيراد دالة البحث - تأكد أن search_tfidf تقبل ثلاث معاملات
from search.tfidf_search import search_tfidf

app = FastAPI(
    title="🔍 Unified Search API",
    description="API موحدة للبحث بعدة طرق وفي عدة قواعد بيانات",
    version="1.0.0"
)

# نموذج طلب البحث
class SearchRequest(BaseModel):
    query: str
    top_k: int = 5
    dataset_name: str

@app.get("/")
def root():
    return {"message": "✅ API تعمل! جرب POST على /search/tfidf"}

@app.post("/search/tfidf")
def tfidf_endpoint(request: SearchRequest):
    try:
        results = search_tfidf(request.query, request.top_k, request.dataset_name)
        return {"method": "tfidf", "query": request.query, "dataset": request.dataset_name, "results": results}
    except Exception as e:
        tb = traceback.format_exc()
        print(f"[ERROR] Exception in tfidf_endpoint:\n{tb}")
        raise HTTPException(status_code=500, detail=str(e))
# ---------------- Word2Vec endpoint ----------------
@app.post("/search/word2vec")
def word2vec_endpoint(request: SearchRequest):
    try:
        results = search_word2vec(request.query, request.top_k, request.dataset_name)
        return {
            "method": "word2vec",
            "query": request.query,
            "dataset": request.dataset_name,
            "results_count": len(results),
            "results": results
        }
    except Exception as e:
        tb = traceback.format_exc()
        print(f"[ERROR] Exception in word2vec_endpoint:\n{tb}")
        raise HTTPException(status_code=500, detail=str(e))

# @app.post("/search/bert")
# def search_bert_endpoint(request: SearchRequest):
#     results = search_bert(request.query, request.top_k, request.dataset_name)
#     return {
#         "method": "bert",
#         "dataset": request.dataset_name,
#         "query": request.query,
#         "results_count": len(results),
#         "results": results
#     }

# @app.post("/search/bm25")
# def search_bm25_endpoint(request: SearchRequest):
#     results = search_bm25(request.query, request.top_k, request.dataset_name)
#     return {
#         "method": "bm25",
#         "dataset": request.dataset_name,
#         "query": request.query,
#         "results_count": len(results),
#         "results": results
#     }

# @app.post("/search/word2vec")
# def search_word2vec_endpoint(request: SearchRequest):
#     results = search_word2vec(request.query, request.top_k, request.dataset_name)
#     return {
#         "method": "word2vec",
#         "dataset": request.dataset_name,
#         "query": request.query,
#         "results_count": len(results),
#         "results": results
#     }

# # يمكنك تكرار نفس النمط لأي طريقة بحث إضافية لديك
