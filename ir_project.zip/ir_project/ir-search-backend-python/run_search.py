import sys
import ranking.custom_preprocessor

# أضف السطرين:
sys.modules['__main__'].custom_preprocessor = ranking.custom_preprocessor.custom_preprocessor
sys.modules['__main__'].custom_tokenizer = ranking.custom_preprocessor.custom_tokenizer

from ranking.ranking import rank_documents
from ranking.query_vectorizer import vectorize_query_word2vec, vectorize_query_tfidf
from joblib import load

if __name__ == "__main__":
    print("🔍 اختر طريقة البحث:")
    print("1 - Word2Vec")
    print("2 - TF-IDF")
    choice = input("أدخل رقم الطريقة: ").strip()

    query_text = input("\n📝 أدخل استعلامك: ")

    if choice == "1":
        print("[INFO] 🧠 استخدام Word2Vec ...")
        query_vector = vectorize_query_word2vec(query_text)
        doc_vectors = load("models/word2vec_vectors.joblib")
        doc_ids = load("models/word2vec_doc_ids.joblib")
    elif choice == "2":
        print("[INFO] 🧠 استخدام TF-IDF ...")
        query_vector = vectorize_query_tfidf(query_text)
        doc_vectors = load("models/tfidf_vectors.joblib")
        doc_ids = load("models/doc_ids.joblib")
    else:
        print("[ERROR] ❌ اختيار غير صحيح")
        exit(1)

    results = rank_documents(query_vector, doc_vectors, doc_ids, method="cosine")

    print("\n📊 أفضل النتائج:")
    for doc_id, score in results[:10]:
        print(f"{doc_id}: {score:.4f}")
