import os
import numpy as np
from joblib import load, dump

def load_vectors(model_dir: str, vector_file: str, id_file: str, limit=None):
    vectors = load(os.path.join(model_dir, vector_file))
    doc_ids = load(os.path.join(model_dir, id_file))

    if isinstance(vectors, np.ndarray):
        vectors = vectors[:limit] if limit else vectors
    elif hasattr(vectors, "toarray"):  # sparse matrix
        vectors = vectors[:limit].toarray() if limit else vectors.toarray()
    elif isinstance(vectors, list):
        vectors = np.array(vectors[:limit]) if limit else np.array(vectors)
    else:
        raise TypeError(f"Unsupported vector type: {type(vectors)}")

    doc_ids = doc_ids[:limit] if limit else doc_ids
    return np.array(doc_ids), np.array(vectors)

def assert_doc_ids_match(doc_ids1, doc_ids2, model1_name, model2_name):
    if not np.array_equal(doc_ids1, doc_ids2):
        raise ValueError(f"[❌ ERROR] doc_ids don't match between {model1_name} and {model2_name}.")

def build_serial_fusion(tfidf_dir, word2vec_dir, output_dir="fusion_models", limit=None):
    print("[🔄] Loading TF-IDF vectors...")
    tfidf_ids, tfidf_vecs = load_vectors(tfidf_dir, "tfidf_vectors.joblib", "doc_ids.joblib", limit)

    print("[🔄] Loading Word2Vec vectors...")
    w2v_ids, w2v_vecs = load_vectors(word2vec_dir, "word2vec_vectors.joblib", "word2vec_doc_ids.joblib", limit)

    print("[🔍] Validating matching document IDs...")
    assert_doc_ids_match(tfidf_ids, w2v_ids, "TF-IDF", "Word2Vec")

    print("[🧠] Concatenating TF-IDF + Word2Vec vectors...")
    fused_vectors = np.hstack((tfidf_vecs, w2v_vecs))

    os.makedirs(output_dir, exist_ok=True)
    dump(fused_vectors, os.path.join(output_dir, "serial_fusion_vectors.joblib"))
    dump(tfidf_ids, os.path.join(output_dir, "serial_fusion_doc_ids.joblib"))

    print("[✅] Serial Fusion vectors saved!")

def cosine_similarity(a, b):
    norm_a = np.linalg.norm(a, axis=1, keepdims=True)
    norm_b = np.linalg.norm(b, axis=1, keepdims=True)
    return np.dot(a, b.T) / (norm_a * norm_b.T + 1e-10)

def build_parallel_fusion(query_vector_dict: dict, vector_files: dict, output_dir="fusion_models", top_k=10, limit=None):
    doc_scores = {}  # {doc_id: cumulative_score}

    for model_name, (vec_path, id_path) in vector_files.items():
        print(f"[🔄] Loading vectors for {model_name}...")
        doc_ids, vectors = load_vectors(os.path.dirname(vec_path), os.path.basename(vec_path), os.path.basename(id_path), limit)
        query_vec = query_vector_dict[model_name]

        print(f"[📊] Calculating cosine similarity for {model_name}...")
        sim_scores = cosine_similarity(query_vec.reshape(1, -1), vectors).flatten()

        print(f"[📥] Aggregating scores for {model_name}...")
        for doc_id, score in zip(doc_ids, sim_scores):
            doc_scores[doc_id] = doc_scores.get(doc_id, 0) + score

    # Sort by cumulative score
    ranked = sorted(doc_scores.items(), key=lambda x: x[1], reverse=True)

    os.makedirs(output_dir, exist_ok=True)
    dump(ranked[:top_k], os.path.join(output_dir, "parallel_fusion_results.joblib"))

    print(f"[✅] Parallel Fusion ranking saved! Top {top_k} docs returned.")
    return ranked[:top_k]

# ** هنا تبدأ دالة البحث المتوازية **
def parallel_fusion_search(user_query, top_k=5):
    print("[🔎] Processing query:", user_query)

    # 1. تحميل أدوات تحويل الاستعلام (مفترض لديك محولات محفوظة)
    from joblib import load
    from core.preprocessor import TextPreprocessor
    preproc = TextPreprocessor()


    # عدل المسارات حسب مكان حفظك للنماذج والمحولات
    tfidf_vectorizer = load("models/tfidf_vectorizer.joblib")  # محول TF-IDF لتحويل نص لاستعلام فيكتور
    word2vec_model = load("models/word2vec_model.joblib")      # نموذج Word2Vec (أو محول لفيكتور)
    word2vec_doc_ids = load("models/word2vec_doc_ids.joblib")  # للتأكد

    # 2. تحويل الاستعلام إلى فيكتور TF-IDF
    tfidf_query_vec = tfidf_vectorizer.transform([user_query]).toarray()[0]

    # 3. تحويل الاستعلام إلى فيكتور Word2Vec
    # (هذه دالة توضيحية فقط، عدلها حسب نموذجك)
    def query_to_word2vec_vector(query, w2v_model):
        tokens = preproc.tokenize(query)
        tokens = preproc.remove_stop_words(tokens)
        tokens = preproc.stem_tokens(tokens)
        vecs = [w2v_model.wv[word] for word in tokens if word in w2v_model.wv]
        if not vecs:
            return np.zeros(w2v_model.vector_size)
        return np.mean(vecs, axis=0)



    w2v_query_vec = query_to_word2vec_vector(user_query, word2vec_model)

    query_vector_dict = {
        "tfidf": tfidf_query_vec,
        "word2vec": w2v_query_vec
    }

    vector_files = {
        "tfidf": ("models/tfidf_vectors.joblib", "models/doc_ids.joblib"),
        "word2vec": ("models/word2vec_vectors.joblib", "models/word2vec_doc_ids.joblib")
    }

    # 4. البحث المتوازي مع دمج النتائج
    top_results = build_parallel_fusion(query_vector_dict, vector_files, top_k=top_k)

    print("[🏁] Top results:")
    for rank, (doc_id, score) in enumerate(top_results, 1):
        print(f"{rank}. Doc ID: {doc_id} | Score: {score:.4f}")

if __name__ == "__main__":
    # تشغيل الدمج التسلسلي على 100 مستند للتجربة
    build_serial_fusion(
        tfidf_dir="models",
        word2vec_dir="models",
        output_dir="fusion_models",
        limit=100
    )
