from sentence_transformers import SentenceTransformer

# Load the pretrained sentence-transformers model (load once)
model_name = "sentence-transformers/all-mpnet-base-v2"
model = SentenceTransformer(model_name)

def encode_text(text):
    """
    Encode text string into a vector embedding using the loaded model.
    """
    return model.encode(text)
