import os
import sys

# إضافة مسار core حتى نتمكن من الاستيراد
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(current_dir, '..'))
sys.path.append(project_root)

from core.preprocessor import TextPreprocessor
from query_processing.vectorizer import encode_text

def process_query(query_text: str):
    print("[INFO] Loading vectorizer model ...")
    # إنشاء preprocessor بنفس الإعدادات التي استعملتها للوثائق
    preproc = TextPreprocessor(use_stemming=False, use_lemmatization=True, remove_stopwords=True)
    
    # تطبيق المعالجة
    processed = preproc.preprocess(query_text)
    
    # الحصول على النص النهائي بعد المعالجة
    final_text = processed['final_text']
    
    # تحويل النص إلى تمثيل رقمي باستخدام نفس النموذج
    query_vector = encode_text(final_text)
    
    return query_vector

if __name__ == "__main__":
    sample_query = "coronavirus treatment vaccine"
    vector = process_query(sample_query)
    print("Query vector shape:", vector.shape)
    print("Vector preview:", vector[:10])  # عرض أول 10 قيم فقط
