import re
import string

def preprocess(text):
    """
    Preprocess the input query string:
    - lowercase
    - remove punctuation
    - remove extra spaces
    """
    text = text.lower()
    text = text.translate(str.maketrans('', '', string.punctuation))
    text = re.sub(r'\s+', ' ', text).strip()
    return text
