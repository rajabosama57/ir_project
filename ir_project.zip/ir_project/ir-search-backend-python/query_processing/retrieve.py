import json
from collections import Counter
from core.preprocessor import TextPreprocessor

def load_inverted_index(path="indexing/inverted_index.json"):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def process_query(query):
    preproc = TextPreprocessor()
    tokens = preproc.tokenize(query)
    tokens = preproc.remove_stop_words(tokens)
    tokens = preproc.stem_tokens(tokens)
    return tokens

def retrieve(query, top_k=10):
    inverted_index = load_inverted_index()
    terms = process_query(query)
    doc_counts = Counter()
    for term in terms:
        if term in inverted_index:
            doc_counts.update(inverted_index[term])
    top_docs = doc_counts.most_common(top_k)
    print(f"Top {top_k} documents for query '{query}':")
    for rank, (doc_id, count) in enumerate(top_docs, 1):
        print(f"{rank}. Doc ID: {doc_id}, Matches: {count}")

if __name__ == "__main__":
    sample_query = "coronavirus treatment vaccine"
    retrieve(sample_query)
