import nltk

# تحميل الموارد إلى مجلد محلي
nltk.download('punkt', download_dir='./nltk_data')
nltk.download('stopwords', download_dir='./nltk_data')
nltk.download('wordnet', download_dir='./nltk_data')
nltk.download('omw-1.4', download_dir='./nltk_data')  # مطلوب لـ WordNet
nltk.download('averaged_perceptron_tagger', download_dir='./nltk_data')

print("✅ تم تحميل جميع الموارد المطلوبة بنجاح.")
