import ir_datasets
import os
import csv
import random

def save_tsv(filepath, rows, header=None):
    with open(filepath, 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f, delimiter='\t')
        if header:
            writer.writerow(header)
        writer.writerows(rows)

def save_qrels(dataset, qrels_dir, allowed_query_ids=None, allowed_doc_ids=None):
    os.makedirs(qrels_dir, exist_ok=True)
    qrels = list(dataset.qrels_iter())
    qrel_file = os.path.join(qrels_dir, "qrels.tsv")
    with open(qrel_file, 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f, delimiter='\t')
        writer.writerow(['query_id', 'iteration', 'doc_id', 'relevance'])
        for qrel in qrels:
            if allowed_query_ids and qrel.query_id not in allowed_query_ids:
                continue
            if allowed_doc_ids and qrel.doc_id not in allowed_doc_ids:
                continue
            writer.writerow([qrel.query_id, qrel.iteration, qrel.doc_id, qrel.relevance])

def take_limited(iterable, max_count):
    items = []
    for i, item in enumerate(iterable):
        if i >= max_count:
            break
        items.append(item)
    return items

def prepare_dataset(dataset_id, output_dir, max_docs=600_000, min_docs=200_000, max_queries=600_000, min_queries=200_000):
    print(f"[INFO] Loading dataset: {dataset_id}")
    dataset = ir_datasets.load(dataset_id)
    os.makedirs(output_dir, exist_ok=True)

    # Documents
    print(f"[INFO] Sampling documents...")
    docs = take_limited(dataset.docs_iter(), max_docs)
    if len(docs) < min_docs:
        raise ValueError(f"[ERROR] Only {len(docs)} documents found, which is less than minimum required {min_docs}.")
    doc_rows = [[doc.doc_id, getattr(doc, 'text', '')] for doc in docs]
    doc_ids = set(doc[0] for doc in doc_rows)
    save_tsv(os.path.join(output_dir, 'documents.tsv'), doc_rows, header=['doc_id', 'text'])
    print(f"[INFO] Saved {len(doc_rows)} documents to documents.tsv")

    # Queries
    print(f"[INFO] Sampling queries...")
    queries = take_limited(dataset.queries_iter(), max_queries)
    if len(queries) < min_queries:
        raise ValueError(f"[ERROR] Only {len(queries)} queries found, which is less than minimum required {min_queries}.")
    query_rows = [
        [q.query_id, getattr(q, 'text', None) or getattr(q, 'query', None) or getattr(q, 'title', None) or '']
        for q in queries
    ]
    query_ids = set(q[0] for q in query_rows)
    save_tsv(os.path.join(output_dir, 'queries.tsv'), query_rows, header=['query_id', 'text'])
    print(f"[INFO] Saved {len(query_rows)} queries to queries.tsv")

    # Qrels
    print(f"[INFO] Filtering and saving qrels...")
    save_qrels(dataset, os.path.join(output_dir, 'qrels'), allowed_query_ids=query_ids, allowed_doc_ids=doc_ids)
    print(f"[INFO] Done.")

if __name__ == "__main__":
    prepare_dataset("beir/trec-covid", "data/cord19", max_docs=250_000, min_docs=100_000, max_queries=10_000, min_queries=10)
    # prepare_dataset("msmarco-passage", "data/msmarco-passage", max_docs=500_000, min_docs=200_000, max_queries=10_000, min_queries=10)
