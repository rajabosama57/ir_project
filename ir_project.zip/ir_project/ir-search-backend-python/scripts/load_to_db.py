import sqlite3
import csv
import os

def create_tables(conn):
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS documents (
            doc_id TEXT PRIMARY KEY,
            title TEXT,
            abstract TEXT,
            original_text TEXT,
            processed_text TEXT
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS queries (
            query_id TEXT PRIMARY KEY,
            text TEXT
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS qrels (
            query_id TEXT,
            iteration INTEGER,
            doc_id TEXT,
            relevance INTEGER,
            PRIMARY KEY (query_id, doc_id)
        )
    ''')
    conn.commit()

def load_documents(conn, filepath):
    print(f"[INFO] 📄 Loading documents from {filepath}...")
    rows = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f, delimiter='\t')
        for row in reader:
            doc_id = row.get("doc_id")
            # التعديل هنا: استخدام عمود "text" فقط وعدم الاعتماد على title أو abstract
            original_text = row.get("text", "").strip()
            title = ""
            abstract = ""
            rows.append((doc_id, title, abstract, original_text, None))  # processed_text = None

    c = conn.cursor()
    c.executemany(
        "INSERT OR IGNORE INTO documents (doc_id, title, abstract, original_text, processed_text) VALUES (?, ?, ?, ?, ?)",
        rows
    )
    conn.commit()
    print(f"[INFO] ✅ Loaded {len(rows)} documents.")

def load_tsv_to_table(conn, filepath, table, columns, rename_map=None):
    print(f"[INFO] Loading {filepath} into {table}...")
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f, delimiter='\t')
        rows = []
        for row in reader:
            if rename_map:
                rows.append(tuple(row[rename_map.get(col, col)] for col in columns))
            else:
                rows.append(tuple(row[col] for col in columns))
        c = conn.cursor()
        c.executemany(
            f"INSERT OR IGNORE INTO {table} ({', '.join(columns)}) VALUES ({', '.join(['?' for _ in columns])})",
            rows
        )
        conn.commit()
    print(f"[INFO] Loaded {len(rows)} rows into {table}.")

def main(data_dir, db_path):
    if not os.path.exists(data_dir):
        raise FileNotFoundError(f"Data directory {data_dir} not found.")
    
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    create_tables(conn)

    docs_file = os.path.join(data_dir, "documents.tsv")
    queries_file = os.path.join(data_dir, "queries.tsv")
    qrels_file = os.path.join(data_dir, "qrels", "qrels.tsv")

    for file in [docs_file, queries_file, qrels_file]:
        if not os.path.isfile(file):
            raise FileNotFoundError(f"Expected file not found: {file}")

    load_documents(conn, docs_file)
    load_tsv_to_table(conn, queries_file, "queries", ["query_id", "text"])
    load_tsv_to_table(conn, qrels_file, "qrels", ["query_id", "iteration", "doc_id", "relevance"])

    print("[INFO] ✅ All data loaded successfully.")
    conn.close()

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Load IR dataset into SQLite database.")
    parser.add_argument("--data_dir", type=str, required=True, help="Path to dataset folder (with documents.tsv, queries.tsv, qrels/qrels.tsv)")
    parser.add_argument("--db_path", type=str, default="db/ir_documents.db", help="Path to SQLite DB file")

    args = parser.parse_args()
    main(args.data_dir, args.db_path)
