import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from core.preprocessor import TextPreprocessor
from core.db_manager import DBManager

def preprocess_documents(db_path: str):
    print("[INFO] Initializing preprocessor and database...")
    preproc = TextPreprocessor()
    db = DBManager(db_path)

    db.create_tables()

    db.cursor.execute("PRAGMA table_info(documents)")
    columns = [col[1] for col in db.cursor.fetchall()]
    source_column = "original_text" if "original_text" in columns else "text"

    print(f"[INFO] Fetching documents from DB using column '{source_column}'...")
    db.cursor.execute(f"SELECT doc_id, {source_column} FROM documents")
    rows = db.cursor.fetchall()
    print(f"[INFO] Found {len(rows)} documents.")

    for i, (doc_id, original_text) in enumerate(rows):
        try:
            processed = preproc.preprocess(original_text)
            final_text = processed["final_text"]

            # إدخال النص الأصلي فقط إذا لم يكن موجود
            db.insert_document(doc_id, original_text)
            # تحديث النص المعالج دائماً
            db.update_processed_text(doc_id, final_text)

            if i % 1000 == 0:
                print(f"[{i}] Processed: {doc_id}")

        except Exception as e:
            print(f"[ERROR] Failed to process doc_id {doc_id}: {e}")

    db.close()
    print("[INFO] ✅ Processing complete.")

if __name__ == "__main__":
    preprocess_documents("db/ir_documents.db")
